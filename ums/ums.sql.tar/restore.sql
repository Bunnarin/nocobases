--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5
-- Dumped by pg_dump version 17.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE ums;
--
-- Name: ums; Type: DATABASE; Schema: -; Owner: nocobase
--

CREATE DATABASE ums WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE ums OWNER TO nocobase;

\connect ums

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: affiliation; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public.affiliation (
    "parentId" bigint,
    id bigint NOT NULL,
    name character varying(255)
);


ALTER TABLE public.affiliation OWNER TO nocobase;

--
-- Name: affiliation_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public.affiliation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.affiliation_id_seq OWNER TO nocobase;

--
-- Name: affiliation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public.affiliation_id_seq OWNED BY public.affiliation.id;


--
-- Name: apiKeys; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."apiKeys" (
    id bigint NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    name character varying(255),
    "roleName" character varying(255),
    "expiresIn" character varying(255),
    token character varying(255),
    sort bigint,
    "createdById" bigint
);


ALTER TABLE public."apiKeys" OWNER TO nocobase;

--
-- Name: apiKeys_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public."apiKeys_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."apiKeys_id_seq" OWNER TO nocobase;

--
-- Name: apiKeys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public."apiKeys_id_seq" OWNED BY public."apiKeys".id;


--
-- Name: applicationPlugins; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."applicationPlugins" (
    id bigint NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    name character varying(255),
    "packageName" character varying(255),
    version character varying(255),
    enabled boolean,
    installed boolean,
    "builtIn" boolean,
    options json
);


ALTER TABLE public."applicationPlugins" OWNER TO nocobase;

--
-- Name: applicationPlugins_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public."applicationPlugins_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."applicationPlugins_id_seq" OWNER TO nocobase;

--
-- Name: applicationPlugins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public."applicationPlugins_id_seq" OWNED BY public."applicationPlugins".id;


--
-- Name: applicationVersion; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."applicationVersion" (
    id bigint NOT NULL,
    value character varying(255)
);


ALTER TABLE public."applicationVersion" OWNER TO nocobase;

--
-- Name: applicationVersion_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public."applicationVersion_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."applicationVersion_id_seq" OWNER TO nocobase;

--
-- Name: applicationVersion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public."applicationVersion_id_seq" OWNED BY public."applicationVersion".id;


--
-- Name: attachments; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public.attachments (
    id bigint NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    title character varying(255),
    filename character varying(255),
    extname character varying(255),
    size integer,
    mimetype character varying(255),
    path text,
    meta jsonb DEFAULT '{}'::jsonb,
    url text,
    "createdById" bigint,
    "updatedById" bigint,
    "storageId" bigint
);


ALTER TABLE public.attachments OWNER TO nocobase;

--
-- Name: COLUMN attachments.title; Type: COMMENT; Schema: public; Owner: nocobase
--

COMMENT ON COLUMN public.attachments.title IS '用户文件名（不含扩展名）';


--
-- Name: COLUMN attachments.filename; Type: COMMENT; Schema: public; Owner: nocobase
--

COMMENT ON COLUMN public.attachments.filename IS '系统文件名（含扩展名）';


--
-- Name: COLUMN attachments.extname; Type: COMMENT; Schema: public; Owner: nocobase
--

COMMENT ON COLUMN public.attachments.extname IS '扩展名（含“.”）';


--
-- Name: COLUMN attachments.size; Type: COMMENT; Schema: public; Owner: nocobase
--

COMMENT ON COLUMN public.attachments.size IS '文件体积（字节）';


--
-- Name: COLUMN attachments.path; Type: COMMENT; Schema: public; Owner: nocobase
--

COMMENT ON COLUMN public.attachments.path IS '相对路径（含“/”前缀）';


--
-- Name: COLUMN attachments.meta; Type: COMMENT; Schema: public; Owner: nocobase
--

COMMENT ON COLUMN public.attachments.meta IS '其他文件信息（如图片的宽高）';


--
-- Name: COLUMN attachments.url; Type: COMMENT; Schema: public; Owner: nocobase
--

COMMENT ON COLUMN public.attachments.url IS '网络访问地址';


--
-- Name: attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public.attachments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attachments_id_seq OWNER TO nocobase;

--
-- Name: attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public.attachments_id_seq OWNED BY public.attachments.id;


--
-- Name: authenticators; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public.authenticators (
    id bigint NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    name character varying(255) NOT NULL,
    "authType" character varying(255) NOT NULL,
    title character varying(255),
    description character varying(255) DEFAULT ''::character varying NOT NULL,
    options json DEFAULT '{}'::json NOT NULL,
    enabled boolean DEFAULT false,
    sort bigint,
    "createdById" bigint,
    "updatedById" bigint
);


ALTER TABLE public.authenticators OWNER TO nocobase;

--
-- Name: authenticators_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public.authenticators_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.authenticators_id_seq OWNER TO nocobase;

--
-- Name: authenticators_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public.authenticators_id_seq OWNED BY public.authenticators.id;


--
-- Name: blockTemplateLinks; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."blockTemplateLinks" (
    id bigint NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "templateKey" character varying(255),
    "templateBlockUid" character varying(255),
    "blockUid" character varying(255)
);


ALTER TABLE public."blockTemplateLinks" OWNER TO nocobase;

--
-- Name: blockTemplateLinks_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public."blockTemplateLinks_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."blockTemplateLinks_id_seq" OWNER TO nocobase;

--
-- Name: blockTemplateLinks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public."blockTemplateLinks_id_seq" OWNED BY public."blockTemplateLinks".id;


--
-- Name: blockTemplates; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."blockTemplates" (
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    key character varying(255) NOT NULL,
    title character varying(255),
    description character varying(255),
    type character varying(255) DEFAULT 'Desktop'::character varying,
    uid character varying(255),
    configured boolean DEFAULT false,
    collection character varying(255),
    "dataSource" character varying(255),
    "componentType" character varying(255),
    "menuName" character varying(255)
);


ALTER TABLE public."blockTemplates" OWNER TO nocobase;

--
-- Name: class; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public.class (
    id bigint NOT NULL,
    name character varying(255),
    affiliation_id bigint
);


ALTER TABLE public.class OWNER TO nocobase;

--
-- Name: class_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public.class_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.class_id_seq OWNER TO nocobase;

--
-- Name: class_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public.class_id_seq OWNED BY public.class.id;


--
-- Name: collectionCategories; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."collectionCategories" (
    id bigint NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    name character varying(255),
    color character varying(255) DEFAULT 'default'::character varying,
    sort bigint
);


ALTER TABLE public."collectionCategories" OWNER TO nocobase;

--
-- Name: collectionCategories_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public."collectionCategories_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."collectionCategories_id_seq" OWNER TO nocobase;

--
-- Name: collectionCategories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public."collectionCategories_id_seq" OWNED BY public."collectionCategories".id;


--
-- Name: collectionCategory; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."collectionCategory" (
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "collectionName" character varying(255) NOT NULL,
    "categoryId" bigint NOT NULL
);


ALTER TABLE public."collectionCategory" OWNER TO nocobase;

--
-- Name: collections; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public.collections (
    key character varying(255) NOT NULL,
    name character varying(255),
    title character varying(255),
    inherit boolean DEFAULT false,
    hidden boolean DEFAULT false,
    options json DEFAULT '{}'::json,
    description character varying(255),
    sort bigint
);


ALTER TABLE public.collections OWNER TO nocobase;

--
-- Name: customRequests; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."customRequests" (
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    key character varying(255) NOT NULL,
    options json
);


ALTER TABLE public."customRequests" OWNER TO nocobase;

--
-- Name: customRequestsRoles; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."customRequestsRoles" (
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "customRequestKey" character varying(255) NOT NULL,
    "roleName" character varying(255) NOT NULL
);


ALTER TABLE public."customRequestsRoles" OWNER TO nocobase;

--
-- Name: dataSources; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."dataSources" (
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    key character varying(255) NOT NULL,
    "displayName" character varying(255),
    type character varying(255),
    options json,
    enabled boolean DEFAULT true,
    fixed boolean DEFAULT false
);


ALTER TABLE public."dataSources" OWNER TO nocobase;

--
-- Name: dataSourcesCollections; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."dataSourcesCollections" (
    key character varying(255) NOT NULL,
    name character varying(255),
    options json,
    "dataSourceKey" character varying(255)
);


ALTER TABLE public."dataSourcesCollections" OWNER TO nocobase;

--
-- Name: dataSourcesFields; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."dataSourcesFields" (
    key character varying(255) NOT NULL,
    name character varying(255),
    "collectionName" character varying(255),
    interface character varying(255),
    description character varying(255),
    "uiSchema" json,
    "collectionKey" character varying(255),
    options json DEFAULT '{}'::json,
    "dataSourceKey" character varying(255)
);


ALTER TABLE public."dataSourcesFields" OWNER TO nocobase;

--
-- Name: dataSourcesRoles; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."dataSourcesRoles" (
    id character varying(255) NOT NULL,
    "roleName" character varying(255),
    strategy json,
    "dataSourceKey" character varying(255)
);


ALTER TABLE public."dataSourcesRoles" OWNER TO nocobase;

--
-- Name: dataSourcesRolesResources; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."dataSourcesRolesResources" (
    id bigint NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "dataSourceKey" character varying(255) DEFAULT 'main'::character varying,
    "roleName" character varying(255),
    name character varying(255),
    "usingActionsConfig" boolean
);


ALTER TABLE public."dataSourcesRolesResources" OWNER TO nocobase;

--
-- Name: dataSourcesRolesResourcesActions; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."dataSourcesRolesResourcesActions" (
    id bigint NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    name character varying(255),
    fields jsonb DEFAULT '[]'::jsonb,
    "scopeId" bigint,
    "rolesResourceId" bigint
);


ALTER TABLE public."dataSourcesRolesResourcesActions" OWNER TO nocobase;

--
-- Name: dataSourcesRolesResourcesActions_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public."dataSourcesRolesResourcesActions_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."dataSourcesRolesResourcesActions_id_seq" OWNER TO nocobase;

--
-- Name: dataSourcesRolesResourcesActions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public."dataSourcesRolesResourcesActions_id_seq" OWNED BY public."dataSourcesRolesResourcesActions".id;


--
-- Name: dataSourcesRolesResourcesScopes; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."dataSourcesRolesResourcesScopes" (
    id bigint NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    key character varying(255),
    "dataSourceKey" character varying(255) DEFAULT 'main'::character varying,
    name character varying(255),
    "resourceName" character varying(255),
    scope json
);


ALTER TABLE public."dataSourcesRolesResourcesScopes" OWNER TO nocobase;

--
-- Name: dataSourcesRolesResourcesScopes_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public."dataSourcesRolesResourcesScopes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."dataSourcesRolesResourcesScopes_id_seq" OWNER TO nocobase;

--
-- Name: dataSourcesRolesResourcesScopes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public."dataSourcesRolesResourcesScopes_id_seq" OWNED BY public."dataSourcesRolesResourcesScopes".id;


--
-- Name: dataSourcesRolesResources_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public."dataSourcesRolesResources_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."dataSourcesRolesResources_id_seq" OWNER TO nocobase;

--
-- Name: dataSourcesRolesResources_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public."dataSourcesRolesResources_id_seq" OWNED BY public."dataSourcesRolesResources".id;


--
-- Name: desktopRoutes; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."desktopRoutes" (
    id bigint NOT NULL,
    "createdAt" timestamp with time zone,
    "updatedAt" timestamp with time zone,
    "parentId" bigint,
    title character varying(255),
    tooltip character varying(255),
    icon character varying(255),
    "schemaUid" character varying(255),
    "menuSchemaUid" character varying(255),
    "tabSchemaName" character varying(255),
    type character varying(255),
    options json,
    sort bigint,
    "hideInMenu" boolean,
    "enableTabs" boolean,
    "enableHeader" boolean,
    "displayTitle" boolean,
    hidden boolean,
    "createdById" bigint,
    "updatedById" bigint
);


ALTER TABLE public."desktopRoutes" OWNER TO nocobase;

--
-- Name: desktopRoutes_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public."desktopRoutes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."desktopRoutes_id_seq" OWNER TO nocobase;

--
-- Name: desktopRoutes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public."desktopRoutes_id_seq" OWNED BY public."desktopRoutes".id;


--
-- Name: environmentVariables; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."environmentVariables" (
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(255),
    value text
);


ALTER TABLE public."environmentVariables" OWNER TO nocobase;

--
-- Name: executions; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public.executions (
    id bigint NOT NULL,
    "createdAt" timestamp with time zone,
    "updatedAt" timestamp with time zone NOT NULL,
    key character varying(255),
    "eventKey" character varying(255),
    context json,
    status integer,
    stack json,
    output json,
    "workflowId" bigint
);


ALTER TABLE public.executions OWNER TO nocobase;

--
-- Name: executions_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public.executions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.executions_id_seq OWNER TO nocobase;

--
-- Name: executions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public.executions_id_seq OWNED BY public.executions.id;


--
-- Name: fields; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public.fields (
    key character varying(255) NOT NULL,
    name character varying(255),
    type character varying(255),
    interface character varying(255),
    description character varying(255),
    "collectionName" character varying(255),
    "parentKey" character varying(255),
    "reverseKey" character varying(255),
    options json DEFAULT '{}'::json,
    sort bigint
);


ALTER TABLE public.fields OWNER TO nocobase;

--
-- Name: flow_nodes; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public.flow_nodes (
    id bigint NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    key character varying(255),
    title character varying(255),
    "upstreamId" bigint,
    "branchIndex" integer,
    "downstreamId" bigint,
    type character varying(255),
    config json DEFAULT '{}'::json,
    "workflowId" bigint
);


ALTER TABLE public.flow_nodes OWNER TO nocobase;

--
-- Name: flow_nodes_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public.flow_nodes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.flow_nodes_id_seq OWNER TO nocobase;

--
-- Name: flow_nodes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public.flow_nodes_id_seq OWNED BY public.flow_nodes.id;


--
-- Name: iframeHtml; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."iframeHtml" (
    id character varying(255) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    html text,
    "createdById" bigint,
    "updatedById" bigint
);


ALTER TABLE public."iframeHtml" OWNER TO nocobase;

--
-- Name: issuedTokens; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."issuedTokens" (
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    id uuid NOT NULL,
    "signInTime" bigint NOT NULL,
    jti uuid NOT NULL,
    "issuedTime" bigint NOT NULL,
    "userId" bigint NOT NULL
);


ALTER TABLE public."issuedTokens" OWNER TO nocobase;

--
-- Name: jobs; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public.jobs (
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    id bigint NOT NULL,
    "executionId" bigint,
    "nodeId" bigint,
    "nodeKey" character varying(255),
    "upstreamId" bigint,
    status integer,
    result json
);


ALTER TABLE public.jobs OWNER TO nocobase;

--
-- Name: llmServices; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."llmServices" (
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    name character varying(255) NOT NULL,
    title character varying(255),
    provider character varying(255),
    options jsonb
);


ALTER TABLE public."llmServices" OWNER TO nocobase;

--
-- Name: main_affiliation_path; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public.main_affiliation_path (
    "nodePk" integer,
    path character varying(1024),
    "rootPk" integer
);


ALTER TABLE public.main_affiliation_path OWNER TO nocobase;

--
-- Name: main_desktopRoutes_path; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."main_desktopRoutes_path" (
    "nodePk" integer,
    path character varying(1024),
    "rootPk" integer
);


ALTER TABLE public."main_desktopRoutes_path" OWNER TO nocobase;

--
-- Name: main_mobileRoutes_path; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."main_mobileRoutes_path" (
    "nodePk" integer,
    path character varying(1024),
    "rootPk" integer
);


ALTER TABLE public."main_mobileRoutes_path" OWNER TO nocobase;

--
-- Name: migrations; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public.migrations (
    name character varying(255) NOT NULL
);


ALTER TABLE public.migrations OWNER TO nocobase;

--
-- Name: mobileRoutes; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."mobileRoutes" (
    id bigint NOT NULL,
    "createdAt" timestamp with time zone,
    "updatedAt" timestamp with time zone,
    "parentId" bigint,
    title character varying(255),
    icon character varying(255),
    "schemaUid" character varying(255),
    type character varying(255),
    options json,
    sort bigint,
    "hideInMenu" boolean,
    "enableTabs" boolean,
    hidden boolean,
    "createdById" bigint,
    "updatedById" bigint
);


ALTER TABLE public."mobileRoutes" OWNER TO nocobase;

--
-- Name: mobileRoutes_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public."mobileRoutes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."mobileRoutes_id_seq" OWNER TO nocobase;

--
-- Name: mobileRoutes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public."mobileRoutes_id_seq" OWNED BY public."mobileRoutes".id;


--
-- Name: notificationChannels; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."notificationChannels" (
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    name character varying(255) NOT NULL,
    title character varying(255),
    options json,
    meta json,
    "notificationType" character varying(255),
    description text,
    "createdById" bigint,
    "updatedById" bigint
);


ALTER TABLE public."notificationChannels" OWNER TO nocobase;

--
-- Name: notificationInAppMessages; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."notificationInAppMessages" (
    id uuid NOT NULL,
    "createdAt" timestamp with time zone,
    "updatedAt" timestamp with time zone NOT NULL,
    "userId" bigint,
    "channelName" character varying(255),
    title text,
    content text,
    status character varying(255),
    "receiveTimestamp" bigint,
    options json
);


ALTER TABLE public."notificationInAppMessages" OWNER TO nocobase;

--
-- Name: notificationSendLogs; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."notificationSendLogs" (
    id uuid NOT NULL,
    "createdAt" timestamp with time zone,
    "updatedAt" timestamp with time zone,
    "channelName" character varying(255),
    "channelTitle" character varying(255),
    "triggerFrom" character varying(255),
    "notificationType" character varying(255),
    status character varying(255),
    message json,
    reason text
);


ALTER TABLE public."notificationSendLogs" OWNER TO nocobase;

--
-- Name: otpRecords; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."otpRecords" (
    id uuid NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    action character varying(255),
    receiver character varying(255),
    status integer DEFAULT 0,
    "expiresAt" bigint,
    code character varying(255),
    "verifierName" character varying(255)
);


ALTER TABLE public."otpRecords" OWNER TO nocobase;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public.roles (
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    name character varying(255) NOT NULL,
    title character varying(255),
    description character varying(255),
    strategy json,
    "default" boolean DEFAULT false,
    hidden boolean DEFAULT false,
    "allowConfigure" boolean,
    "allowNewMenu" boolean,
    snippets jsonb DEFAULT '["!ui.*", "!pm", "!pm.*"]'::jsonb,
    sort bigint,
    "allowNewMobileMenu" boolean
);


ALTER TABLE public.roles OWNER TO nocobase;

--
-- Name: rolesDesktopRoutes; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."rolesDesktopRoutes" (
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "desktopRouteId" bigint NOT NULL,
    "roleName" character varying(255) NOT NULL
);


ALTER TABLE public."rolesDesktopRoutes" OWNER TO nocobase;

--
-- Name: rolesMobileRoutes; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."rolesMobileRoutes" (
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "mobileRouteId" bigint NOT NULL,
    "roleName" character varying(255) NOT NULL
);


ALTER TABLE public."rolesMobileRoutes" OWNER TO nocobase;

--
-- Name: rolesResources; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."rolesResources" (
    id bigint NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "roleName" character varying(255),
    name character varying(255),
    "usingActionsConfig" boolean
);


ALTER TABLE public."rolesResources" OWNER TO nocobase;

--
-- Name: rolesResourcesActions; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."rolesResourcesActions" (
    id bigint NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "rolesResourceId" bigint,
    name character varying(255),
    fields jsonb DEFAULT '[]'::jsonb,
    "scopeId" bigint
);


ALTER TABLE public."rolesResourcesActions" OWNER TO nocobase;

--
-- Name: rolesResourcesActions_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public."rolesResourcesActions_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."rolesResourcesActions_id_seq" OWNER TO nocobase;

--
-- Name: rolesResourcesActions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public."rolesResourcesActions_id_seq" OWNED BY public."rolesResourcesActions".id;


--
-- Name: rolesResourcesScopes; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."rolesResourcesScopes" (
    id bigint NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    key character varying(255),
    name character varying(255),
    "resourceName" character varying(255),
    scope json
);


ALTER TABLE public."rolesResourcesScopes" OWNER TO nocobase;

--
-- Name: rolesResourcesScopes_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public."rolesResourcesScopes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."rolesResourcesScopes_id_seq" OWNER TO nocobase;

--
-- Name: rolesResourcesScopes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public."rolesResourcesScopes_id_seq" OWNED BY public."rolesResourcesScopes".id;


--
-- Name: rolesResources_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public."rolesResources_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."rolesResources_id_seq" OWNER TO nocobase;

--
-- Name: rolesResources_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public."rolesResources_id_seq" OWNED BY public."rolesResources".id;


--
-- Name: rolesUischemas; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."rolesUischemas" (
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "roleName" character varying(255) NOT NULL,
    "uiSchemaXUid" character varying(255) NOT NULL
);


ALTER TABLE public."rolesUischemas" OWNER TO nocobase;

--
-- Name: rolesUsers; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."rolesUsers" (
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "default" boolean,
    "roleName" character varying(255) NOT NULL,
    "userId" bigint NOT NULL
);


ALTER TABLE public."rolesUsers" OWNER TO nocobase;

--
-- Name: schedule; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public.schedule (
    id bigint NOT NULL,
    subject_id bigint,
    user_id bigint,
    monday character varying(255),
    tuesday character varying(255),
    wednesday character varying(255),
    thursday character varying(255),
    friday character varying(255),
    saturday character varying(255),
    sunday character varying(255),
    class_id bigint
);


ALTER TABLE public.schedule OWNER TO nocobase;

--
-- Name: schedule_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public.schedule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.schedule_id_seq OWNER TO nocobase;

--
-- Name: schedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public.schedule_id_seq OWNED BY public.schedule.id;


--
-- Name: score; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public.score (
    id bigint NOT NULL,
    subject_id bigint,
    value double precision,
    student_id bigint
);


ALTER TABLE public.score OWNER TO nocobase;

--
-- Name: score_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public.score_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.score_id_seq OWNER TO nocobase;

--
-- Name: score_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public.score_id_seq OWNED BY public.score.id;


--
-- Name: sequences; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public.sequences (
    id bigint NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    collection character varying(255),
    field character varying(255),
    key integer,
    current bigint,
    "lastGeneratedAt" timestamp with time zone
);


ALTER TABLE public.sequences OWNER TO nocobase;

--
-- Name: sequences_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public.sequences_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sequences_id_seq OWNER TO nocobase;

--
-- Name: sequences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public.sequences_id_seq OWNED BY public.sequences.id;


--
-- Name: storages; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public.storages (
    id bigint NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    title character varying(255),
    name character varying(255),
    type character varying(255),
    options jsonb DEFAULT '{}'::jsonb,
    rules jsonb DEFAULT '{}'::jsonb,
    path text DEFAULT ''::text,
    "baseUrl" character varying(255) DEFAULT ''::character varying,
    "default" boolean DEFAULT false,
    paranoid boolean DEFAULT false
);


ALTER TABLE public.storages OWNER TO nocobase;

--
-- Name: COLUMN storages.title; Type: COMMENT; Schema: public; Owner: nocobase
--

COMMENT ON COLUMN public.storages.title IS '存储引擎名称';


--
-- Name: COLUMN storages.type; Type: COMMENT; Schema: public; Owner: nocobase
--

COMMENT ON COLUMN public.storages.type IS '类型标识，如 local/ali-oss 等';


--
-- Name: COLUMN storages.options; Type: COMMENT; Schema: public; Owner: nocobase
--

COMMENT ON COLUMN public.storages.options IS '配置项';


--
-- Name: COLUMN storages.rules; Type: COMMENT; Schema: public; Owner: nocobase
--

COMMENT ON COLUMN public.storages.rules IS '文件规则';


--
-- Name: COLUMN storages.path; Type: COMMENT; Schema: public; Owner: nocobase
--

COMMENT ON COLUMN public.storages.path IS '存储相对路径模板';


--
-- Name: COLUMN storages."baseUrl"; Type: COMMENT; Schema: public; Owner: nocobase
--

COMMENT ON COLUMN public.storages."baseUrl" IS '访问地址前缀';


--
-- Name: COLUMN storages."default"; Type: COMMENT; Schema: public; Owner: nocobase
--

COMMENT ON COLUMN public.storages."default" IS '默认引擎';


--
-- Name: storages_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public.storages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.storages_id_seq OWNER TO nocobase;

--
-- Name: storages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public.storages_id_seq OWNED BY public.storages.id;


--
-- Name: student; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public.student (
    id bigint NOT NULL,
    class_id bigint,
    user_id bigint
);


ALTER TABLE public.student OWNER TO nocobase;

--
-- Name: student_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public.student_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.student_id_seq OWNER TO nocobase;

--
-- Name: student_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public.student_id_seq OWNED BY public.student.id;


--
-- Name: subject; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public.subject (
    id bigint NOT NULL,
    name character varying(255),
    affiliation_id bigint
);


ALTER TABLE public.subject OWNER TO nocobase;

--
-- Name: subject_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public.subject_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.subject_id_seq OWNER TO nocobase;

--
-- Name: subject_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public.subject_id_seq OWNED BY public.subject.id;


--
-- Name: systemSettings; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."systemSettings" (
    id bigint NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    title character varying(255),
    "showLogoOnly" boolean,
    "allowSignUp" boolean DEFAULT true,
    "smsAuthEnabled" boolean DEFAULT false,
    "logoId" bigint,
    "enabledLanguages" json DEFAULT '[]'::json,
    "appLang" character varying(255),
    options json DEFAULT '{}'::json,
    "roleMode" character varying(255) DEFAULT 'default'::character varying,
    "enableEditProfile" boolean,
    "enableChangePassword" boolean
);


ALTER TABLE public."systemSettings" OWNER TO nocobase;

--
-- Name: systemSettings_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public."systemSettings_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."systemSettings_id_seq" OWNER TO nocobase;

--
-- Name: systemSettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public."systemSettings_id_seq" OWNED BY public."systemSettings".id;


--
-- Name: t_js3c1e4rwku; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public.t_js3c1e4rwku (
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    class_id bigint NOT NULL,
    user_id bigint NOT NULL
);


ALTER TABLE public.t_js3c1e4rwku OWNER TO nocobase;

--
-- Name: t_zys6z6hrol7; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public.t_zys6z6hrol7 (
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    user_id bigint NOT NULL,
    affiliation_id bigint NOT NULL
);


ALTER TABLE public.t_zys6z6hrol7 OWNER TO nocobase;

--
-- Name: themeConfig; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."themeConfig" (
    id bigint NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    config json,
    optional boolean,
    "isBuiltIn" boolean,
    uid character varying(255),
    "default" boolean DEFAULT false
);


ALTER TABLE public."themeConfig" OWNER TO nocobase;

--
-- Name: themeConfig_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public."themeConfig_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."themeConfig_id_seq" OWNER TO nocobase;

--
-- Name: themeConfig_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public."themeConfig_id_seq" OWNED BY public."themeConfig".id;


--
-- Name: tokenBlacklist; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."tokenBlacklist" (
    id bigint NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    token character varying(255),
    expiration timestamp with time zone
);


ALTER TABLE public."tokenBlacklist" OWNER TO nocobase;

--
-- Name: tokenBlacklist_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public."tokenBlacklist_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."tokenBlacklist_id_seq" OWNER TO nocobase;

--
-- Name: tokenBlacklist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public."tokenBlacklist_id_seq" OWNED BY public."tokenBlacklist".id;


--
-- Name: tokenControlConfig; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."tokenControlConfig" (
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    key character varying(255) NOT NULL,
    config json DEFAULT '{}'::json NOT NULL,
    "createdById" bigint,
    "updatedById" bigint
);


ALTER TABLE public."tokenControlConfig" OWNER TO nocobase;

--
-- Name: uiButtonSchemasRoles; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."uiButtonSchemasRoles" (
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    uid character varying(255),
    "roleName" character varying(255)
);


ALTER TABLE public."uiButtonSchemasRoles" OWNER TO nocobase;

--
-- Name: uiSchemaServerHooks; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."uiSchemaServerHooks" (
    id bigint NOT NULL,
    type character varying(255),
    collection character varying(255),
    field character varying(255),
    method character varying(255),
    params json,
    uid character varying(255)
);


ALTER TABLE public."uiSchemaServerHooks" OWNER TO nocobase;

--
-- Name: uiSchemaServerHooks_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public."uiSchemaServerHooks_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."uiSchemaServerHooks_id_seq" OWNER TO nocobase;

--
-- Name: uiSchemaServerHooks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public."uiSchemaServerHooks_id_seq" OWNED BY public."uiSchemaServerHooks".id;


--
-- Name: uiSchemaTemplates; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."uiSchemaTemplates" (
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    key character varying(255) NOT NULL,
    name character varying(255),
    "componentName" character varying(255),
    "associationName" character varying(255),
    "resourceName" character varying(255),
    "collectionName" character varying(255),
    "dataSourceKey" character varying(255),
    uid character varying(255)
);


ALTER TABLE public."uiSchemaTemplates" OWNER TO nocobase;

--
-- Name: uiSchemaTreePath; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."uiSchemaTreePath" (
    ancestor character varying(255) NOT NULL,
    descendant character varying(255) NOT NULL,
    depth integer,
    async boolean,
    type character varying(255),
    sort integer
);


ALTER TABLE public."uiSchemaTreePath" OWNER TO nocobase;

--
-- Name: COLUMN "uiSchemaTreePath".type; Type: COMMENT; Schema: public; Owner: nocobase
--

COMMENT ON COLUMN public."uiSchemaTreePath".type IS 'type of node';


--
-- Name: COLUMN "uiSchemaTreePath".sort; Type: COMMENT; Schema: public; Owner: nocobase
--

COMMENT ON COLUMN public."uiSchemaTreePath".sort IS 'sort of node in adjacency';


--
-- Name: uiSchemas; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."uiSchemas" (
    "x-uid" character varying(255) NOT NULL,
    name character varying(255),
    schema json DEFAULT '{}'::json
);


ALTER TABLE public."uiSchemas" OWNER TO nocobase;

--
-- Name: userDataSyncRecords; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."userDataSyncRecords" (
    id bigint NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "sourceName" character varying(255) NOT NULL,
    "sourceUk" character varying(255) NOT NULL,
    "dataType" character varying(255) NOT NULL,
    "metaData" json,
    "lastMetaData" json
);


ALTER TABLE public."userDataSyncRecords" OWNER TO nocobase;

--
-- Name: userDataSyncRecordsResources; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."userDataSyncRecordsResources" (
    id bigint NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "recordId" bigint,
    resource character varying(255) NOT NULL,
    "resourcePk" character varying(255)
);


ALTER TABLE public."userDataSyncRecordsResources" OWNER TO nocobase;

--
-- Name: userDataSyncRecordsResources_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public."userDataSyncRecordsResources_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."userDataSyncRecordsResources_id_seq" OWNER TO nocobase;

--
-- Name: userDataSyncRecordsResources_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public."userDataSyncRecordsResources_id_seq" OWNED BY public."userDataSyncRecordsResources".id;


--
-- Name: userDataSyncRecords_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public."userDataSyncRecords_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."userDataSyncRecords_id_seq" OWNER TO nocobase;

--
-- Name: userDataSyncRecords_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public."userDataSyncRecords_id_seq" OWNED BY public."userDataSyncRecords".id;


--
-- Name: userDataSyncSources; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."userDataSyncSources" (
    id bigint NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    name character varying(255) NOT NULL,
    "sourceType" character varying(255) NOT NULL,
    "displayName" character varying(255),
    enabled boolean DEFAULT false,
    options json DEFAULT '{}'::json NOT NULL,
    sort bigint,
    "createdById" bigint,
    "updatedById" bigint
);


ALTER TABLE public."userDataSyncSources" OWNER TO nocobase;

--
-- Name: userDataSyncSources_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public."userDataSyncSources_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."userDataSyncSources_id_seq" OWNER TO nocobase;

--
-- Name: userDataSyncSources_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public."userDataSyncSources_id_seq" OWNED BY public."userDataSyncSources".id;


--
-- Name: userDataSyncTasks; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."userDataSyncTasks" (
    id bigint NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    batch character varying(255) NOT NULL,
    "sourceId" bigint,
    status character varying(255) NOT NULL,
    message character varying(255),
    cost integer,
    sort bigint,
    "createdById" bigint,
    "updatedById" bigint
);


ALTER TABLE public."userDataSyncTasks" OWNER TO nocobase;

--
-- Name: userDataSyncTasks_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public."userDataSyncTasks_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."userDataSyncTasks_id_seq" OWNER TO nocobase;

--
-- Name: userDataSyncTasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public."userDataSyncTasks_id_seq" OWNED BY public."userDataSyncTasks".id;


--
-- Name: userWorkflowTasks; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."userWorkflowTasks" (
    id bigint NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "userId" bigint,
    type character varying(255),
    stats json DEFAULT '{}'::json
);


ALTER TABLE public."userWorkflowTasks" OWNER TO nocobase;

--
-- Name: userWorkflowTasks_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public."userWorkflowTasks_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."userWorkflowTasks_id_seq" OWNER TO nocobase;

--
-- Name: userWorkflowTasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public."userWorkflowTasks_id_seq" OWNED BY public."userWorkflowTasks".id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    "createdAt" timestamp with time zone,
    "updatedAt" timestamp with time zone,
    nickname character varying(255),
    username character varying(255),
    email character varying(255),
    phone character varying(255),
    password character varying(255),
    "passwordChangeTz" bigint,
    "appLang" character varying(255),
    "resetToken" character varying(255),
    "systemSettings" json DEFAULT '{}'::json,
    sort bigint,
    "createdById" bigint,
    "updatedById" bigint
);


ALTER TABLE public.users OWNER TO nocobase;

--
-- Name: usersAuthenticators; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."usersAuthenticators" (
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    uuid character varying(255) NOT NULL,
    nickname character varying(255) DEFAULT ''::character varying NOT NULL,
    avatar character varying(255) DEFAULT ''::character varying NOT NULL,
    meta json DEFAULT '{}'::json,
    "createdById" bigint,
    "updatedById" bigint,
    authenticator character varying(255) NOT NULL,
    "userId" bigint NOT NULL
);


ALTER TABLE public."usersAuthenticators" OWNER TO nocobase;

--
-- Name: usersVerificators; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."usersVerificators" (
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    uuid character varying(255) NOT NULL,
    meta json DEFAULT '{}'::json,
    "createdById" bigint,
    "updatedById" bigint,
    verificator character varying(255) NOT NULL,
    "userId" bigint NOT NULL
);


ALTER TABLE public."usersVerificators" OWNER TO nocobase;

--
-- Name: usersVerifiers; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."usersVerifiers" (
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    uuid character varying(255) NOT NULL,
    meta json DEFAULT '{}'::json,
    "createdById" bigint,
    "updatedById" bigint,
    verifier character varying(255) NOT NULL,
    "userId" bigint NOT NULL
);


ALTER TABLE public."usersVerifiers" OWNER TO nocobase;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO nocobase;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: verifications; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public.verifications (
    id uuid NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    type character varying(255),
    receiver character varying(255),
    status integer DEFAULT 0,
    "expiresAt" timestamp with time zone,
    content character varying(255),
    "providerId" character varying(255)
);


ALTER TABLE public.verifications OWNER TO nocobase;

--
-- Name: verifications_providers; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public.verifications_providers (
    id character varying(255) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    title character varying(255),
    type character varying(255),
    options jsonb,
    "default" boolean
);


ALTER TABLE public.verifications_providers OWNER TO nocobase;

--
-- Name: verificators; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public.verificators (
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    name character varying(255) NOT NULL,
    title character varying(255),
    "verificationType" character varying(255),
    description character varying(255),
    options jsonb
);


ALTER TABLE public.verificators OWNER TO nocobase;

--
-- Name: verifiers; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public.verifiers (
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    name character varying(255) NOT NULL,
    title character varying(255),
    "verificationType" character varying(255),
    description character varying(255),
    options jsonb
);


ALTER TABLE public.verifiers OWNER TO nocobase;

--
-- Name: workflowCategories; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."workflowCategories" (
    id bigint NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    title character varying(255),
    color character varying(255) DEFAULT 'default'::character varying,
    sort bigint
);


ALTER TABLE public."workflowCategories" OWNER TO nocobase;

--
-- Name: workflowCategories_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public."workflowCategories_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."workflowCategories_id_seq" OWNER TO nocobase;

--
-- Name: workflowCategories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public."workflowCategories_id_seq" OWNED BY public."workflowCategories".id;


--
-- Name: workflowCategoryRelations; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."workflowCategoryRelations" (
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "workflowCategoryId" bigint,
    "workflowId" bigint NOT NULL,
    "categoryId" bigint NOT NULL
);


ALTER TABLE public."workflowCategoryRelations" OWNER TO nocobase;

--
-- Name: workflowStats; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."workflowStats" (
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    key character varying(255) NOT NULL,
    executed bigint DEFAULT 0
);


ALTER TABLE public."workflowStats" OWNER TO nocobase;

--
-- Name: workflowTasks; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."workflowTasks" (
    id bigint NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "userId" bigint,
    type character varying(255),
    key character varying(255),
    "workflowId" bigint
);


ALTER TABLE public."workflowTasks" OWNER TO nocobase;

--
-- Name: workflowTasks_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public."workflowTasks_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."workflowTasks_id_seq" OWNER TO nocobase;

--
-- Name: workflowTasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public."workflowTasks_id_seq" OWNED BY public."workflowTasks".id;


--
-- Name: workflowVersionStats; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public."workflowVersionStats" (
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    id bigint NOT NULL,
    executed bigint DEFAULT 0
);


ALTER TABLE public."workflowVersionStats" OWNER TO nocobase;

--
-- Name: workflows; Type: TABLE; Schema: public; Owner: nocobase
--

CREATE TABLE public.workflows (
    id bigint NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    key character varying(255),
    title character varying(255),
    enabled boolean DEFAULT false,
    description text,
    type character varying(255),
    "triggerTitle" character varying(255),
    config jsonb DEFAULT '{}'::jsonb,
    executed integer DEFAULT 0,
    "allExecuted" integer DEFAULT 0,
    current boolean,
    sync boolean DEFAULT false,
    options jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.workflows OWNER TO nocobase;

--
-- Name: workflows_id_seq; Type: SEQUENCE; Schema: public; Owner: nocobase
--

CREATE SEQUENCE public.workflows_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.workflows_id_seq OWNER TO nocobase;

--
-- Name: workflows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nocobase
--

ALTER SEQUENCE public.workflows_id_seq OWNED BY public.workflows.id;


--
-- Name: affiliation id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.affiliation ALTER COLUMN id SET DEFAULT nextval('public.affiliation_id_seq'::regclass);


--
-- Name: apiKeys id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."apiKeys" ALTER COLUMN id SET DEFAULT nextval('public."apiKeys_id_seq"'::regclass);


--
-- Name: applicationPlugins id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."applicationPlugins" ALTER COLUMN id SET DEFAULT nextval('public."applicationPlugins_id_seq"'::regclass);


--
-- Name: applicationVersion id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."applicationVersion" ALTER COLUMN id SET DEFAULT nextval('public."applicationVersion_id_seq"'::regclass);


--
-- Name: attachments id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.attachments ALTER COLUMN id SET DEFAULT nextval('public.attachments_id_seq'::regclass);


--
-- Name: authenticators id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.authenticators ALTER COLUMN id SET DEFAULT nextval('public.authenticators_id_seq'::regclass);


--
-- Name: blockTemplateLinks id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."blockTemplateLinks" ALTER COLUMN id SET DEFAULT nextval('public."blockTemplateLinks_id_seq"'::regclass);


--
-- Name: class id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.class ALTER COLUMN id SET DEFAULT nextval('public.class_id_seq'::regclass);


--
-- Name: collectionCategories id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."collectionCategories" ALTER COLUMN id SET DEFAULT nextval('public."collectionCategories_id_seq"'::regclass);


--
-- Name: dataSourcesRolesResources id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."dataSourcesRolesResources" ALTER COLUMN id SET DEFAULT nextval('public."dataSourcesRolesResources_id_seq"'::regclass);


--
-- Name: dataSourcesRolesResourcesActions id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."dataSourcesRolesResourcesActions" ALTER COLUMN id SET DEFAULT nextval('public."dataSourcesRolesResourcesActions_id_seq"'::regclass);


--
-- Name: dataSourcesRolesResourcesScopes id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."dataSourcesRolesResourcesScopes" ALTER COLUMN id SET DEFAULT nextval('public."dataSourcesRolesResourcesScopes_id_seq"'::regclass);


--
-- Name: desktopRoutes id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."desktopRoutes" ALTER COLUMN id SET DEFAULT nextval('public."desktopRoutes_id_seq"'::regclass);


--
-- Name: executions id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.executions ALTER COLUMN id SET DEFAULT nextval('public.executions_id_seq'::regclass);


--
-- Name: flow_nodes id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.flow_nodes ALTER COLUMN id SET DEFAULT nextval('public.flow_nodes_id_seq'::regclass);


--
-- Name: mobileRoutes id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."mobileRoutes" ALTER COLUMN id SET DEFAULT nextval('public."mobileRoutes_id_seq"'::regclass);


--
-- Name: rolesResources id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."rolesResources" ALTER COLUMN id SET DEFAULT nextval('public."rolesResources_id_seq"'::regclass);


--
-- Name: rolesResourcesActions id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."rolesResourcesActions" ALTER COLUMN id SET DEFAULT nextval('public."rolesResourcesActions_id_seq"'::regclass);


--
-- Name: rolesResourcesScopes id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."rolesResourcesScopes" ALTER COLUMN id SET DEFAULT nextval('public."rolesResourcesScopes_id_seq"'::regclass);


--
-- Name: schedule id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.schedule ALTER COLUMN id SET DEFAULT nextval('public.schedule_id_seq'::regclass);


--
-- Name: score id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.score ALTER COLUMN id SET DEFAULT nextval('public.score_id_seq'::regclass);


--
-- Name: sequences id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.sequences ALTER COLUMN id SET DEFAULT nextval('public.sequences_id_seq'::regclass);


--
-- Name: storages id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.storages ALTER COLUMN id SET DEFAULT nextval('public.storages_id_seq'::regclass);


--
-- Name: student id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.student ALTER COLUMN id SET DEFAULT nextval('public.student_id_seq'::regclass);


--
-- Name: subject id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.subject ALTER COLUMN id SET DEFAULT nextval('public.subject_id_seq'::regclass);


--
-- Name: systemSettings id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."systemSettings" ALTER COLUMN id SET DEFAULT nextval('public."systemSettings_id_seq"'::regclass);


--
-- Name: themeConfig id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."themeConfig" ALTER COLUMN id SET DEFAULT nextval('public."themeConfig_id_seq"'::regclass);


--
-- Name: tokenBlacklist id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."tokenBlacklist" ALTER COLUMN id SET DEFAULT nextval('public."tokenBlacklist_id_seq"'::regclass);


--
-- Name: uiSchemaServerHooks id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."uiSchemaServerHooks" ALTER COLUMN id SET DEFAULT nextval('public."uiSchemaServerHooks_id_seq"'::regclass);


--
-- Name: userDataSyncRecords id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."userDataSyncRecords" ALTER COLUMN id SET DEFAULT nextval('public."userDataSyncRecords_id_seq"'::regclass);


--
-- Name: userDataSyncRecordsResources id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."userDataSyncRecordsResources" ALTER COLUMN id SET DEFAULT nextval('public."userDataSyncRecordsResources_id_seq"'::regclass);


--
-- Name: userDataSyncSources id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."userDataSyncSources" ALTER COLUMN id SET DEFAULT nextval('public."userDataSyncSources_id_seq"'::regclass);


--
-- Name: userDataSyncTasks id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."userDataSyncTasks" ALTER COLUMN id SET DEFAULT nextval('public."userDataSyncTasks_id_seq"'::regclass);


--
-- Name: userWorkflowTasks id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."userWorkflowTasks" ALTER COLUMN id SET DEFAULT nextval('public."userWorkflowTasks_id_seq"'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: workflowCategories id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."workflowCategories" ALTER COLUMN id SET DEFAULT nextval('public."workflowCategories_id_seq"'::regclass);


--
-- Name: workflowTasks id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."workflowTasks" ALTER COLUMN id SET DEFAULT nextval('public."workflowTasks_id_seq"'::regclass);


--
-- Name: workflows id; Type: DEFAULT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.workflows ALTER COLUMN id SET DEFAULT nextval('public.workflows_id_seq'::regclass);


--
-- Data for Name: affiliation; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public.affiliation ("parentId", id, name) FROM stdin;
\.
COPY public.affiliation ("parentId", id, name) FROM '$$PATH$$/5734.dat';

--
-- Data for Name: apiKeys; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."apiKeys" (id, "createdAt", name, "roleName", "expiresIn", token, sort, "createdById") FROM stdin;
\.
COPY public."apiKeys" (id, "createdAt", name, "roleName", "expiresIn", token, sort, "createdById") FROM '$$PATH$$/5749.dat';

--
-- Data for Name: applicationPlugins; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."applicationPlugins" (id, "createdAt", "updatedAt", name, "packageName", version, enabled, installed, "builtIn", options) FROM stdin;
\.
COPY public."applicationPlugins" (id, "createdAt", "updatedAt", name, "packageName", version, enabled, installed, "builtIn", options) FROM '$$PATH$$/5631.dat';

--
-- Data for Name: applicationVersion; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."applicationVersion" (id, value) FROM stdin;
\.
COPY public."applicationVersion" (id, value) FROM '$$PATH$$/5633.dat';

--
-- Data for Name: attachments; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public.attachments (id, "createdAt", "updatedAt", title, filename, extname, size, mimetype, path, meta, url, "createdById", "updatedById", "storageId") FROM stdin;
\.
COPY public.attachments (id, "createdAt", "updatedAt", title, filename, extname, size, mimetype, path, meta, url, "createdById", "updatedById", "storageId") FROM '$$PATH$$/5675.dat';

--
-- Data for Name: authenticators; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public.authenticators (id, "createdAt", "updatedAt", name, "authType", title, description, options, enabled, sort, "createdById", "updatedById") FROM stdin;
\.
COPY public.authenticators (id, "createdAt", "updatedAt", name, "authType", title, description, options, enabled, sort, "createdById", "updatedById") FROM '$$PATH$$/5645.dat';

--
-- Data for Name: blockTemplateLinks; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."blockTemplateLinks" (id, "createdAt", "updatedAt", "templateKey", "templateBlockUid", "blockUid") FROM stdin;
\.
COPY public."blockTemplateLinks" (id, "createdAt", "updatedAt", "templateKey", "templateBlockUid", "blockUid") FROM '$$PATH$$/5731.dat';

--
-- Data for Name: blockTemplates; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."blockTemplates" ("createdAt", "updatedAt", key, title, description, type, uid, configured, collection, "dataSource", "componentType", "menuName") FROM stdin;
\.
COPY public."blockTemplates" ("createdAt", "updatedAt", key, title, description, type, uid, configured, collection, "dataSource", "componentType", "menuName") FROM '$$PATH$$/5732.dat';

--
-- Data for Name: class; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public.class (id, name, affiliation_id) FROM stdin;
\.
COPY public.class (id, name, affiliation_id) FROM '$$PATH$$/5744.dat';

--
-- Data for Name: collectionCategories; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."collectionCategories" (id, "createdAt", "updatedAt", name, color, sort) FROM stdin;
\.
COPY public."collectionCategories" (id, "createdAt", "updatedAt", name, color, sort) FROM '$$PATH$$/5668.dat';

--
-- Data for Name: collectionCategory; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."collectionCategory" ("createdAt", "updatedAt", "collectionName", "categoryId") FROM stdin;
\.
COPY public."collectionCategory" ("createdAt", "updatedAt", "collectionName", "categoryId") FROM '$$PATH$$/5670.dat';

--
-- Data for Name: collections; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public.collections (key, name, title, inherit, hidden, options, description, sort) FROM stdin;
\.
COPY public.collections (key, name, title, inherit, hidden, options, description, sort) FROM '$$PATH$$/5669.dat';

--
-- Data for Name: customRequests; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."customRequests" ("createdAt", "updatedAt", key, options) FROM stdin;
\.
COPY public."customRequests" ("createdAt", "updatedAt", key, options) FROM '$$PATH$$/5642.dat';

--
-- Data for Name: customRequestsRoles; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."customRequestsRoles" ("createdAt", "updatedAt", "customRequestKey", "roleName") FROM stdin;
\.
COPY public."customRequestsRoles" ("createdAt", "updatedAt", "customRequestKey", "roleName") FROM '$$PATH$$/5643.dat';

--
-- Data for Name: dataSources; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."dataSources" ("createdAt", "updatedAt", key, "displayName", type, options, enabled, fixed) FROM stdin;
\.
COPY public."dataSources" ("createdAt", "updatedAt", key, "displayName", type, options, enabled, fixed) FROM '$$PATH$$/5665.dat';

--
-- Data for Name: dataSourcesCollections; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."dataSourcesCollections" (key, name, options, "dataSourceKey") FROM stdin;
\.
COPY public."dataSourcesCollections" (key, name, options, "dataSourceKey") FROM '$$PATH$$/5656.dat';

--
-- Data for Name: dataSourcesFields; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."dataSourcesFields" (key, name, "collectionName", interface, description, "uiSchema", "collectionKey", options, "dataSourceKey") FROM stdin;
\.
COPY public."dataSourcesFields" (key, name, "collectionName", interface, description, "uiSchema", "collectionKey", options, "dataSourceKey") FROM '$$PATH$$/5657.dat';

--
-- Data for Name: dataSourcesRoles; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."dataSourcesRoles" (id, "roleName", strategy, "dataSourceKey") FROM stdin;
\.
COPY public."dataSourcesRoles" (id, "roleName", strategy, "dataSourceKey") FROM '$$PATH$$/5664.dat';

--
-- Data for Name: dataSourcesRolesResources; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."dataSourcesRolesResources" (id, "createdAt", "updatedAt", "dataSourceKey", "roleName", name, "usingActionsConfig") FROM stdin;
\.
COPY public."dataSourcesRolesResources" (id, "createdAt", "updatedAt", "dataSourceKey", "roleName", name, "usingActionsConfig") FROM '$$PATH$$/5663.dat';

--
-- Data for Name: dataSourcesRolesResourcesActions; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."dataSourcesRolesResourcesActions" (id, "createdAt", "updatedAt", name, fields, "scopeId", "rolesResourceId") FROM stdin;
\.
COPY public."dataSourcesRolesResourcesActions" (id, "createdAt", "updatedAt", name, fields, "scopeId", "rolesResourceId") FROM '$$PATH$$/5659.dat';

--
-- Data for Name: dataSourcesRolesResourcesScopes; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."dataSourcesRolesResourcesScopes" (id, "createdAt", "updatedAt", key, "dataSourceKey", name, "resourceName", scope) FROM stdin;
\.
COPY public."dataSourcesRolesResourcesScopes" (id, "createdAt", "updatedAt", key, "dataSourceKey", name, "resourceName", scope) FROM '$$PATH$$/5661.dat';

--
-- Data for Name: desktopRoutes; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."desktopRoutes" (id, "createdAt", "updatedAt", "parentId", title, tooltip, icon, "schemaUid", "menuSchemaUid", "tabSchemaName", type, options, sort, "hideInMenu", "enableTabs", "enableHeader", "displayTitle", hidden, "createdById", "updatedById") FROM stdin;
\.
COPY public."desktopRoutes" (id, "createdAt", "updatedAt", "parentId", title, tooltip, icon, "schemaUid", "menuSchemaUid", "tabSchemaName", type, options, sort, "hideInMenu", "enableTabs", "enableHeader", "displayTitle", hidden, "createdById", "updatedById") FROM '$$PATH$$/5653.dat';

--
-- Data for Name: environmentVariables; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."environmentVariables" ("createdAt", "updatedAt", name, type, value) FROM stdin;
\.
COPY public."environmentVariables" ("createdAt", "updatedAt", name, type, value) FROM '$$PATH$$/5666.dat';

--
-- Data for Name: executions; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public.executions (id, "createdAt", "updatedAt", key, "eventKey", context, status, stack, output, "workflowId") FROM stdin;
\.
COPY public.executions (id, "createdAt", "updatedAt", key, "eventKey", context, status, stack, output, "workflowId") FROM '$$PATH$$/5709.dat';

--
-- Data for Name: fields; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public.fields (key, name, type, interface, description, "collectionName", "parentKey", "reverseKey", options, sort) FROM stdin;
\.
COPY public.fields (key, name, type, interface, description, "collectionName", "parentKey", "reverseKey", options, sort) FROM '$$PATH$$/5671.dat';

--
-- Data for Name: flow_nodes; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public.flow_nodes (id, "createdAt", "updatedAt", key, title, "upstreamId", "branchIndex", "downstreamId", type, config, "workflowId") FROM stdin;
\.
COPY public.flow_nodes (id, "createdAt", "updatedAt", key, title, "upstreamId", "branchIndex", "downstreamId", type, config, "workflowId") FROM '$$PATH$$/5711.dat';

--
-- Data for Name: iframeHtml; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."iframeHtml" (id, "createdAt", "updatedAt", html, "createdById", "updatedById") FROM stdin;
\.
COPY public."iframeHtml" (id, "createdAt", "updatedAt", html, "createdById", "updatedById") FROM '$$PATH$$/5651.dat';

--
-- Data for Name: issuedTokens; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."issuedTokens" ("createdAt", "updatedAt", id, "signInTime", jti, "issuedTime", "userId") FROM stdin;
\.
COPY public."issuedTokens" ("createdAt", "updatedAt", id, "signInTime", jti, "issuedTime", "userId") FROM '$$PATH$$/5646.dat';

--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public.jobs ("createdAt", "updatedAt", id, "executionId", "nodeId", "nodeKey", "upstreamId", status, result) FROM stdin;
\.
COPY public.jobs ("createdAt", "updatedAt", id, "executionId", "nodeId", "nodeKey", "upstreamId", status, result) FROM '$$PATH$$/5712.dat';

--
-- Data for Name: llmServices; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."llmServices" ("createdAt", "updatedAt", name, title, provider, options) FROM stdin;
\.
COPY public."llmServices" ("createdAt", "updatedAt", name, title, provider, options) FROM '$$PATH$$/5724.dat';

--
-- Data for Name: main_affiliation_path; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public.main_affiliation_path ("nodePk", path, "rootPk") FROM stdin;
\.
COPY public.main_affiliation_path ("nodePk", path, "rootPk") FROM '$$PATH$$/5735.dat';

--
-- Data for Name: main_desktopRoutes_path; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."main_desktopRoutes_path" ("nodePk", path, "rootPk") FROM stdin;
\.
COPY public."main_desktopRoutes_path" ("nodePk", path, "rootPk") FROM '$$PATH$$/5654.dat';

--
-- Data for Name: main_mobileRoutes_path; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."main_mobileRoutes_path" ("nodePk", path, "rootPk") FROM stdin;
\.
COPY public."main_mobileRoutes_path" ("nodePk", path, "rootPk") FROM '$$PATH$$/5680.dat';

--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public.migrations (name) FROM stdin;
\.
COPY public.migrations (name) FROM '$$PATH$$/5629.dat';

--
-- Data for Name: mobileRoutes; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."mobileRoutes" (id, "createdAt", "updatedAt", "parentId", title, icon, "schemaUid", type, options, sort, "hideInMenu", "enableTabs", hidden, "createdById", "updatedById") FROM stdin;
\.
COPY public."mobileRoutes" (id, "createdAt", "updatedAt", "parentId", title, icon, "schemaUid", type, options, sort, "hideInMenu", "enableTabs", hidden, "createdById", "updatedById") FROM '$$PATH$$/5679.dat';

--
-- Data for Name: notificationChannels; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."notificationChannels" ("createdAt", "updatedAt", name, title, options, meta, "notificationType", description, "createdById", "updatedById") FROM stdin;
\.
COPY public."notificationChannels" ("createdAt", "updatedAt", name, title, options, meta, "notificationType", description, "createdById", "updatedById") FROM '$$PATH$$/5725.dat';

--
-- Data for Name: notificationInAppMessages; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."notificationInAppMessages" (id, "createdAt", "updatedAt", "userId", "channelName", title, content, status, "receiveTimestamp", options) FROM stdin;
\.
COPY public."notificationInAppMessages" (id, "createdAt", "updatedAt", "userId", "channelName", title, content, status, "receiveTimestamp", options) FROM '$$PATH$$/5727.dat';

--
-- Data for Name: notificationSendLogs; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."notificationSendLogs" (id, "createdAt", "updatedAt", "channelName", "channelTitle", "triggerFrom", "notificationType", status, message, reason) FROM stdin;
\.
COPY public."notificationSendLogs" (id, "createdAt", "updatedAt", "channelName", "channelTitle", "triggerFrom", "notificationType", status, message, reason) FROM '$$PATH$$/5726.dat';

--
-- Data for Name: otpRecords; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."otpRecords" (id, "createdAt", "updatedAt", action, receiver, status, "expiresAt", code, "verifierName") FROM stdin;
\.
COPY public."otpRecords" (id, "createdAt", "updatedAt", action, receiver, status, "expiresAt", code, "verifierName") FROM '$$PATH$$/5701.dat';

--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public.roles ("createdAt", "updatedAt", name, title, description, strategy, "default", hidden, "allowConfigure", "allowNewMenu", snippets, sort, "allowNewMobileMenu") FROM stdin;
\.
COPY public.roles ("createdAt", "updatedAt", name, title, description, strategy, "default", hidden, "allowConfigure", "allowNewMenu", snippets, sort, "allowNewMobileMenu") FROM '$$PATH$$/5635.dat';

--
-- Data for Name: rolesDesktopRoutes; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."rolesDesktopRoutes" ("createdAt", "updatedAt", "desktopRouteId", "roleName") FROM stdin;
\.
COPY public."rolesDesktopRoutes" ("createdAt", "updatedAt", "desktopRouteId", "roleName") FROM '$$PATH$$/5655.dat';

--
-- Data for Name: rolesMobileRoutes; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."rolesMobileRoutes" ("createdAt", "updatedAt", "mobileRouteId", "roleName") FROM stdin;
\.
COPY public."rolesMobileRoutes" ("createdAt", "updatedAt", "mobileRouteId", "roleName") FROM '$$PATH$$/5681.dat';

--
-- Data for Name: rolesResources; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."rolesResources" (id, "createdAt", "updatedAt", "roleName", name, "usingActionsConfig") FROM stdin;
\.
COPY public."rolesResources" (id, "createdAt", "updatedAt", "roleName", name, "usingActionsConfig") FROM '$$PATH$$/5637.dat';

--
-- Data for Name: rolesResourcesActions; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."rolesResourcesActions" (id, "createdAt", "updatedAt", "rolesResourceId", name, fields, "scopeId") FROM stdin;
\.
COPY public."rolesResourcesActions" (id, "createdAt", "updatedAt", "rolesResourceId", name, fields, "scopeId") FROM '$$PATH$$/5639.dat';

--
-- Data for Name: rolesResourcesScopes; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."rolesResourcesScopes" (id, "createdAt", "updatedAt", key, name, "resourceName", scope) FROM stdin;
\.
COPY public."rolesResourcesScopes" (id, "createdAt", "updatedAt", key, name, "resourceName", scope) FROM '$$PATH$$/5641.dat';

--
-- Data for Name: rolesUischemas; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."rolesUischemas" ("createdAt", "updatedAt", "roleName", "uiSchemaXUid") FROM stdin;
\.
COPY public."rolesUischemas" ("createdAt", "updatedAt", "roleName", "uiSchemaXUid") FROM '$$PATH$$/5690.dat';

--
-- Data for Name: rolesUsers; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."rolesUsers" ("createdAt", "updatedAt", "default", "roleName", "userId") FROM stdin;
\.
COPY public."rolesUsers" ("createdAt", "updatedAt", "default", "roleName", "userId") FROM '$$PATH$$/5634.dat';

--
-- Data for Name: schedule; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public.schedule (id, subject_id, user_id, monday, tuesday, wednesday, thursday, friday, saturday, sunday, class_id) FROM stdin;
\.
COPY public.schedule (id, subject_id, user_id, monday, tuesday, wednesday, thursday, friday, saturday, sunday, class_id) FROM '$$PATH$$/5746.dat';

--
-- Data for Name: score; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public.score (id, subject_id, value, student_id) FROM stdin;
\.
COPY public.score (id, subject_id, value, student_id) FROM '$$PATH$$/5742.dat';

--
-- Data for Name: sequences; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public.sequences (id, "createdAt", "updatedAt", collection, field, key, current, "lastGeneratedAt") FROM stdin;
\.
COPY public.sequences (id, "createdAt", "updatedAt", collection, field, key, current, "lastGeneratedAt") FROM '$$PATH$$/5673.dat';

--
-- Data for Name: storages; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public.storages (id, "createdAt", "updatedAt", title, name, type, options, rules, path, "baseUrl", "default", paranoid) FROM stdin;
\.
COPY public.storages (id, "createdAt", "updatedAt", title, name, type, options, rules, path, "baseUrl", "default", paranoid) FROM '$$PATH$$/5677.dat';

--
-- Data for Name: student; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public.student (id, class_id, user_id) FROM stdin;
\.
COPY public.student (id, class_id, user_id) FROM '$$PATH$$/5737.dat';

--
-- Data for Name: subject; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public.subject (id, name, affiliation_id) FROM stdin;
\.
COPY public.subject (id, name, affiliation_id) FROM '$$PATH$$/5740.dat';

--
-- Data for Name: systemSettings; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."systemSettings" (id, "createdAt", "updatedAt", title, "showLogoOnly", "allowSignUp", "smsAuthEnabled", "logoId", "enabledLanguages", "appLang", options, "roleMode", "enableEditProfile", "enableChangePassword") FROM stdin;
\.
COPY public."systemSettings" (id, "createdAt", "updatedAt", title, "showLogoOnly", "allowSignUp", "smsAuthEnabled", "logoId", "enabledLanguages", "appLang", options, "roleMode", "enableEditProfile", "enableChangePassword") FROM '$$PATH$$/5683.dat';

--
-- Data for Name: t_js3c1e4rwku; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public.t_js3c1e4rwku ("createdAt", "updatedAt", class_id, user_id) FROM stdin;
\.
COPY public.t_js3c1e4rwku ("createdAt", "updatedAt", class_id, user_id) FROM '$$PATH$$/5747.dat';

--
-- Data for Name: t_zys6z6hrol7; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public.t_zys6z6hrol7 ("createdAt", "updatedAt", user_id, affiliation_id) FROM stdin;
\.
COPY public.t_zys6z6hrol7 ("createdAt", "updatedAt", user_id, affiliation_id) FROM '$$PATH$$/5738.dat';

--
-- Data for Name: themeConfig; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."themeConfig" (id, "createdAt", "updatedAt", config, optional, "isBuiltIn", uid, "default") FROM stdin;
\.
COPY public."themeConfig" (id, "createdAt", "updatedAt", config, optional, "isBuiltIn", uid, "default") FROM '$$PATH$$/5729.dat';

--
-- Data for Name: tokenBlacklist; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."tokenBlacklist" (id, "createdAt", "updatedAt", token, expiration) FROM stdin;
\.
COPY public."tokenBlacklist" (id, "createdAt", "updatedAt", token, expiration) FROM '$$PATH$$/5648.dat';

--
-- Data for Name: tokenControlConfig; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."tokenControlConfig" ("createdAt", "updatedAt", key, config, "createdById", "updatedById") FROM stdin;
\.
COPY public."tokenControlConfig" ("createdAt", "updatedAt", key, config, "createdById", "updatedById") FROM '$$PATH$$/5649.dat';

--
-- Data for Name: uiButtonSchemasRoles; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."uiButtonSchemasRoles" ("createdAt", "updatedAt", uid, "roleName") FROM stdin;
\.
COPY public."uiButtonSchemasRoles" ("createdAt", "updatedAt", uid, "roleName") FROM '$$PATH$$/5684.dat';

--
-- Data for Name: uiSchemaServerHooks; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."uiSchemaServerHooks" (id, type, collection, field, method, params, uid) FROM stdin;
\.
COPY public."uiSchemaServerHooks" (id, type, collection, field, method, params, uid) FROM '$$PATH$$/5686.dat';

--
-- Data for Name: uiSchemaTemplates; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."uiSchemaTemplates" ("createdAt", "updatedAt", key, name, "componentName", "associationName", "resourceName", "collectionName", "dataSourceKey", uid) FROM stdin;
\.
COPY public."uiSchemaTemplates" ("createdAt", "updatedAt", key, name, "componentName", "associationName", "resourceName", "collectionName", "dataSourceKey", uid) FROM '$$PATH$$/5687.dat';

--
-- Data for Name: uiSchemaTreePath; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."uiSchemaTreePath" (ancestor, descendant, depth, async, type, sort) FROM stdin;
\.
COPY public."uiSchemaTreePath" (ancestor, descendant, depth, async, type, sort) FROM '$$PATH$$/5688.dat';

--
-- Data for Name: uiSchemas; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."uiSchemas" ("x-uid", name, schema) FROM stdin;
\.
COPY public."uiSchemas" ("x-uid", name, schema) FROM '$$PATH$$/5689.dat';

--
-- Data for Name: userDataSyncRecords; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."userDataSyncRecords" (id, "createdAt", "updatedAt", "sourceName", "sourceUk", "dataType", "metaData", "lastMetaData") FROM stdin;
\.
COPY public."userDataSyncRecords" (id, "createdAt", "updatedAt", "sourceName", "sourceUk", "dataType", "metaData", "lastMetaData") FROM '$$PATH$$/5694.dat';

--
-- Data for Name: userDataSyncRecordsResources; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."userDataSyncRecordsResources" (id, "createdAt", "updatedAt", "recordId", resource, "resourcePk") FROM stdin;
\.
COPY public."userDataSyncRecordsResources" (id, "createdAt", "updatedAt", "recordId", resource, "resourcePk") FROM '$$PATH$$/5692.dat';

--
-- Data for Name: userDataSyncSources; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."userDataSyncSources" (id, "createdAt", "updatedAt", name, "sourceType", "displayName", enabled, options, sort, "createdById", "updatedById") FROM stdin;
\.
COPY public."userDataSyncSources" (id, "createdAt", "updatedAt", name, "sourceType", "displayName", enabled, options, sort, "createdById", "updatedById") FROM '$$PATH$$/5696.dat';

--
-- Data for Name: userDataSyncTasks; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."userDataSyncTasks" (id, "createdAt", "updatedAt", batch, "sourceId", status, message, cost, sort, "createdById", "updatedById") FROM stdin;
\.
COPY public."userDataSyncTasks" (id, "createdAt", "updatedAt", batch, "sourceId", status, message, cost, sort, "createdById", "updatedById") FROM '$$PATH$$/5698.dat';

--
-- Data for Name: userWorkflowTasks; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."userWorkflowTasks" (id, "createdAt", "updatedAt", "userId", type, stats) FROM stdin;
\.
COPY public."userWorkflowTasks" (id, "createdAt", "updatedAt", "userId", type, stats) FROM '$$PATH$$/5714.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public.users (id, "createdAt", "updatedAt", nickname, username, email, phone, password, "passwordChangeTz", "appLang", "resetToken", "systemSettings", sort, "createdById", "updatedById") FROM stdin;
\.
COPY public.users (id, "createdAt", "updatedAt", nickname, username, email, phone, password, "passwordChangeTz", "appLang", "resetToken", "systemSettings", sort, "createdById", "updatedById") FROM '$$PATH$$/5700.dat';

--
-- Data for Name: usersAuthenticators; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."usersAuthenticators" ("createdAt", "updatedAt", uuid, nickname, avatar, meta, "createdById", "updatedById", authenticator, "userId") FROM stdin;
\.
COPY public."usersAuthenticators" ("createdAt", "updatedAt", uuid, nickname, avatar, meta, "createdById", "updatedById", authenticator, "userId") FROM '$$PATH$$/5650.dat';

--
-- Data for Name: usersVerificators; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."usersVerificators" ("createdAt", "updatedAt", uuid, meta, "createdById", "updatedById", verificator, "userId") FROM stdin;
\.
COPY public."usersVerificators" ("createdAt", "updatedAt", uuid, meta, "createdById", "updatedById", verificator, "userId") FROM '$$PATH$$/5702.dat';

--
-- Data for Name: usersVerifiers; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."usersVerifiers" ("createdAt", "updatedAt", uuid, meta, "createdById", "updatedById", verifier, "userId") FROM stdin;
\.
COPY public."usersVerifiers" ("createdAt", "updatedAt", uuid, meta, "createdById", "updatedById", verifier, "userId") FROM '$$PATH$$/5703.dat';

--
-- Data for Name: verifications; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public.verifications (id, "createdAt", "updatedAt", type, receiver, status, "expiresAt", content, "providerId") FROM stdin;
\.
COPY public.verifications (id, "createdAt", "updatedAt", type, receiver, status, "expiresAt", content, "providerId") FROM '$$PATH$$/5704.dat';

--
-- Data for Name: verifications_providers; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public.verifications_providers (id, "createdAt", "updatedAt", title, type, options, "default") FROM stdin;
\.
COPY public.verifications_providers (id, "createdAt", "updatedAt", title, type, options, "default") FROM '$$PATH$$/5705.dat';

--
-- Data for Name: verificators; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public.verificators ("createdAt", "updatedAt", name, title, "verificationType", description, options) FROM stdin;
\.
COPY public.verificators ("createdAt", "updatedAt", name, title, "verificationType", description, options) FROM '$$PATH$$/5706.dat';

--
-- Data for Name: verifiers; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public.verifiers ("createdAt", "updatedAt", name, title, "verificationType", description, options) FROM stdin;
\.
COPY public.verifiers ("createdAt", "updatedAt", name, title, "verificationType", description, options) FROM '$$PATH$$/5707.dat';

--
-- Data for Name: workflowCategories; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."workflowCategories" (id, "createdAt", "updatedAt", title, color, sort) FROM stdin;
\.
COPY public."workflowCategories" (id, "createdAt", "updatedAt", title, color, sort) FROM '$$PATH$$/5716.dat';

--
-- Data for Name: workflowCategoryRelations; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."workflowCategoryRelations" ("createdAt", "updatedAt", "workflowCategoryId", "workflowId", "categoryId") FROM stdin;
\.
COPY public."workflowCategoryRelations" ("createdAt", "updatedAt", "workflowCategoryId", "workflowId", "categoryId") FROM '$$PATH$$/5717.dat';

--
-- Data for Name: workflowStats; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."workflowStats" ("createdAt", "updatedAt", key, executed) FROM stdin;
\.
COPY public."workflowStats" ("createdAt", "updatedAt", key, executed) FROM '$$PATH$$/5718.dat';

--
-- Data for Name: workflowTasks; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."workflowTasks" (id, "createdAt", "updatedAt", "userId", type, key, "workflowId") FROM stdin;
\.
COPY public."workflowTasks" (id, "createdAt", "updatedAt", "userId", type, key, "workflowId") FROM '$$PATH$$/5720.dat';

--
-- Data for Name: workflowVersionStats; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public."workflowVersionStats" ("createdAt", "updatedAt", id, executed) FROM stdin;
\.
COPY public."workflowVersionStats" ("createdAt", "updatedAt", id, executed) FROM '$$PATH$$/5721.dat';

--
-- Data for Name: workflows; Type: TABLE DATA; Schema: public; Owner: nocobase
--

COPY public.workflows (id, "createdAt", "updatedAt", key, title, enabled, description, type, "triggerTitle", config, executed, "allExecuted", current, sync, options) FROM stdin;
\.
COPY public.workflows (id, "createdAt", "updatedAt", key, title, enabled, description, type, "triggerTitle", config, executed, "allExecuted", current, sync, options) FROM '$$PATH$$/5723.dat';

--
-- Name: affiliation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public.affiliation_id_seq', 2, true);


--
-- Name: apiKeys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public."apiKeys_id_seq"', 1, true);


--
-- Name: applicationPlugins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public."applicationPlugins_id_seq"', 51, true);


--
-- Name: applicationVersion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public."applicationVersion_id_seq"', 10, true);


--
-- Name: attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public.attachments_id_seq', 1, true);


--
-- Name: authenticators_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public.authenticators_id_seq', 1, true);


--
-- Name: blockTemplateLinks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public."blockTemplateLinks_id_seq"', 1, false);


--
-- Name: class_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public.class_id_seq', 2, true);


--
-- Name: collectionCategories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public."collectionCategories_id_seq"', 2, true);


--
-- Name: dataSourcesRolesResourcesActions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public."dataSourcesRolesResourcesActions_id_seq"', 5, true);


--
-- Name: dataSourcesRolesResourcesScopes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public."dataSourcesRolesResourcesScopes_id_seq"', 2, true);


--
-- Name: dataSourcesRolesResources_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public."dataSourcesRolesResources_id_seq"', 3, true);


--
-- Name: desktopRoutes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public."desktopRoutes_id_seq"', 16, true);


--
-- Name: executions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public.executions_id_seq', 1, false);


--
-- Name: flow_nodes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public.flow_nodes_id_seq', 1, false);


--
-- Name: mobileRoutes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public."mobileRoutes_id_seq"', 1, false);


--
-- Name: rolesResourcesActions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public."rolesResourcesActions_id_seq"', 1, false);


--
-- Name: rolesResourcesScopes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public."rolesResourcesScopes_id_seq"', 1, false);


--
-- Name: rolesResources_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public."rolesResources_id_seq"', 1, false);


--
-- Name: schedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public.schedule_id_seq', 2, true);


--
-- Name: score_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public.score_id_seq', 6, true);


--
-- Name: sequences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public.sequences_id_seq', 1, false);


--
-- Name: storages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public.storages_id_seq', 1, true);


--
-- Name: student_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public.student_id_seq', 2, true);


--
-- Name: subject_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public.subject_id_seq', 1, true);


--
-- Name: systemSettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public."systemSettings_id_seq"', 1, true);


--
-- Name: themeConfig_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public."themeConfig_id_seq"', 4, true);


--
-- Name: tokenBlacklist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public."tokenBlacklist_id_seq"', 1, false);


--
-- Name: uiSchemaServerHooks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public."uiSchemaServerHooks_id_seq"', 1, false);


--
-- Name: userDataSyncRecordsResources_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public."userDataSyncRecordsResources_id_seq"', 1, false);


--
-- Name: userDataSyncRecords_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public."userDataSyncRecords_id_seq"', 1, false);


--
-- Name: userDataSyncSources_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public."userDataSyncSources_id_seq"', 1, false);


--
-- Name: userDataSyncTasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public."userDataSyncTasks_id_seq"', 1, false);


--
-- Name: userWorkflowTasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public."userWorkflowTasks_id_seq"', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public.users_id_seq', 3, true);


--
-- Name: workflowCategories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public."workflowCategories_id_seq"', 1, false);


--
-- Name: workflowTasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public."workflowTasks_id_seq"', 1, false);


--
-- Name: workflows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nocobase
--

SELECT pg_catalog.setval('public.workflows_id_seq', 1, false);


--
-- Name: affiliation affiliation_name_key; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.affiliation
    ADD CONSTRAINT affiliation_name_key UNIQUE (name);


--
-- Name: affiliation affiliation_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.affiliation
    ADD CONSTRAINT affiliation_pkey PRIMARY KEY (id);


--
-- Name: apiKeys apiKeys_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."apiKeys"
    ADD CONSTRAINT "apiKeys_pkey" PRIMARY KEY (id);


--
-- Name: applicationPlugins applicationPlugins_name_key; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."applicationPlugins"
    ADD CONSTRAINT "applicationPlugins_name_key" UNIQUE (name);


--
-- Name: applicationPlugins applicationPlugins_packageName_key; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."applicationPlugins"
    ADD CONSTRAINT "applicationPlugins_packageName_key" UNIQUE ("packageName");


--
-- Name: applicationPlugins applicationPlugins_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."applicationPlugins"
    ADD CONSTRAINT "applicationPlugins_pkey" PRIMARY KEY (id);


--
-- Name: applicationVersion applicationVersion_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."applicationVersion"
    ADD CONSTRAINT "applicationVersion_pkey" PRIMARY KEY (id);


--
-- Name: attachments attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_pkey PRIMARY KEY (id);


--
-- Name: authenticators authenticators_name_key; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.authenticators
    ADD CONSTRAINT authenticators_name_key UNIQUE (name);


--
-- Name: authenticators authenticators_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.authenticators
    ADD CONSTRAINT authenticators_pkey PRIMARY KEY (id);


--
-- Name: blockTemplateLinks blockTemplateLinks_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."blockTemplateLinks"
    ADD CONSTRAINT "blockTemplateLinks_pkey" PRIMARY KEY (id);


--
-- Name: blockTemplates blockTemplates_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."blockTemplates"
    ADD CONSTRAINT "blockTemplates_pkey" PRIMARY KEY (key);


--
-- Name: class class_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.class
    ADD CONSTRAINT class_pkey PRIMARY KEY (id);


--
-- Name: collectionCategories collectionCategories_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."collectionCategories"
    ADD CONSTRAINT "collectionCategories_pkey" PRIMARY KEY (id);


--
-- Name: collectionCategory collectionCategory_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."collectionCategory"
    ADD CONSTRAINT "collectionCategory_pkey" PRIMARY KEY ("collectionName", "categoryId");


--
-- Name: collections collections_name_key; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.collections
    ADD CONSTRAINT collections_name_key UNIQUE (name);


--
-- Name: collections collections_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.collections
    ADD CONSTRAINT collections_pkey PRIMARY KEY (key);


--
-- Name: customRequestsRoles customRequestsRoles_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."customRequestsRoles"
    ADD CONSTRAINT "customRequestsRoles_pkey" PRIMARY KEY ("customRequestKey", "roleName");


--
-- Name: customRequests customRequests_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."customRequests"
    ADD CONSTRAINT "customRequests_pkey" PRIMARY KEY (key);


--
-- Name: dataSourcesCollections dataSourcesCollections_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."dataSourcesCollections"
    ADD CONSTRAINT "dataSourcesCollections_pkey" PRIMARY KEY (key);


--
-- Name: dataSourcesFields dataSourcesFields_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."dataSourcesFields"
    ADD CONSTRAINT "dataSourcesFields_pkey" PRIMARY KEY (key);


--
-- Name: dataSourcesRolesResourcesActions dataSourcesRolesResourcesActions_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."dataSourcesRolesResourcesActions"
    ADD CONSTRAINT "dataSourcesRolesResourcesActions_pkey" PRIMARY KEY (id);


--
-- Name: dataSourcesRolesResourcesScopes dataSourcesRolesResourcesScopes_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."dataSourcesRolesResourcesScopes"
    ADD CONSTRAINT "dataSourcesRolesResourcesScopes_pkey" PRIMARY KEY (id);


--
-- Name: dataSourcesRolesResources dataSourcesRolesResources_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."dataSourcesRolesResources"
    ADD CONSTRAINT "dataSourcesRolesResources_pkey" PRIMARY KEY (id);


--
-- Name: dataSourcesRoles dataSourcesRoles_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."dataSourcesRoles"
    ADD CONSTRAINT "dataSourcesRoles_pkey" PRIMARY KEY (id);


--
-- Name: dataSources dataSources_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."dataSources"
    ADD CONSTRAINT "dataSources_pkey" PRIMARY KEY (key);


--
-- Name: desktopRoutes desktopRoutes_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."desktopRoutes"
    ADD CONSTRAINT "desktopRoutes_pkey" PRIMARY KEY (id);


--
-- Name: environmentVariables environmentVariables_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."environmentVariables"
    ADD CONSTRAINT "environmentVariables_pkey" PRIMARY KEY (name);


--
-- Name: executions executions_eventKey_key; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.executions
    ADD CONSTRAINT "executions_eventKey_key" UNIQUE ("eventKey");


--
-- Name: executions executions_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.executions
    ADD CONSTRAINT executions_pkey PRIMARY KEY (id);


--
-- Name: fields fields_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.fields
    ADD CONSTRAINT fields_pkey PRIMARY KEY (key);


--
-- Name: flow_nodes flow_nodes_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.flow_nodes
    ADD CONSTRAINT flow_nodes_pkey PRIMARY KEY (id);


--
-- Name: iframeHtml iframeHtml_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."iframeHtml"
    ADD CONSTRAINT "iframeHtml_pkey" PRIMARY KEY (id);


--
-- Name: issuedTokens issuedTokens_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."issuedTokens"
    ADD CONSTRAINT "issuedTokens_pkey" PRIMARY KEY (id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: llmServices llmServices_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."llmServices"
    ADD CONSTRAINT "llmServices_pkey" PRIMARY KEY (name);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (name);


--
-- Name: mobileRoutes mobileRoutes_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."mobileRoutes"
    ADD CONSTRAINT "mobileRoutes_pkey" PRIMARY KEY (id);


--
-- Name: notificationChannels notificationChannels_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."notificationChannels"
    ADD CONSTRAINT "notificationChannels_pkey" PRIMARY KEY (name);


--
-- Name: notificationInAppMessages notificationInAppMessages_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."notificationInAppMessages"
    ADD CONSTRAINT "notificationInAppMessages_pkey" PRIMARY KEY (id);


--
-- Name: notificationSendLogs notificationSendLogs_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."notificationSendLogs"
    ADD CONSTRAINT "notificationSendLogs_pkey" PRIMARY KEY (id);


--
-- Name: otpRecords otpRecords_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."otpRecords"
    ADD CONSTRAINT "otpRecords_pkey" PRIMARY KEY (id);


--
-- Name: rolesDesktopRoutes rolesDesktopRoutes_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."rolesDesktopRoutes"
    ADD CONSTRAINT "rolesDesktopRoutes_pkey" PRIMARY KEY ("desktopRouteId", "roleName");


--
-- Name: rolesMobileRoutes rolesMobileRoutes_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."rolesMobileRoutes"
    ADD CONSTRAINT "rolesMobileRoutes_pkey" PRIMARY KEY ("mobileRouteId", "roleName");


--
-- Name: rolesResourcesActions rolesResourcesActions_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."rolesResourcesActions"
    ADD CONSTRAINT "rolesResourcesActions_pkey" PRIMARY KEY (id);


--
-- Name: rolesResourcesScopes rolesResourcesScopes_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."rolesResourcesScopes"
    ADD CONSTRAINT "rolesResourcesScopes_pkey" PRIMARY KEY (id);


--
-- Name: rolesResources rolesResources_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."rolesResources"
    ADD CONSTRAINT "rolesResources_pkey" PRIMARY KEY (id);


--
-- Name: rolesUischemas rolesUischemas_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."rolesUischemas"
    ADD CONSTRAINT "rolesUischemas_pkey" PRIMARY KEY ("roleName", "uiSchemaXUid");


--
-- Name: rolesUsers rolesUsers_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."rolesUsers"
    ADD CONSTRAINT "rolesUsers_pkey" PRIMARY KEY ("roleName", "userId");


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (name);


--
-- Name: roles roles_title_key; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_title_key UNIQUE (title);


--
-- Name: schedule schedule_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.schedule
    ADD CONSTRAINT schedule_pkey PRIMARY KEY (id);


--
-- Name: score score_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.score
    ADD CONSTRAINT score_pkey PRIMARY KEY (id);


--
-- Name: sequences sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.sequences
    ADD CONSTRAINT sequences_pkey PRIMARY KEY (id);


--
-- Name: storages storages_name_key; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.storages
    ADD CONSTRAINT storages_name_key UNIQUE (name);


--
-- Name: storages storages_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.storages
    ADD CONSTRAINT storages_pkey PRIMARY KEY (id);


--
-- Name: student student_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.student
    ADD CONSTRAINT student_pkey PRIMARY KEY (id);


--
-- Name: subject subject_name_key; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.subject
    ADD CONSTRAINT subject_name_key UNIQUE (name);


--
-- Name: subject subject_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.subject
    ADD CONSTRAINT subject_pkey PRIMARY KEY (id);


--
-- Name: systemSettings systemSettings_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."systemSettings"
    ADD CONSTRAINT "systemSettings_pkey" PRIMARY KEY (id);


--
-- Name: t_js3c1e4rwku t_js3c1e4rwku_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.t_js3c1e4rwku
    ADD CONSTRAINT t_js3c1e4rwku_pkey PRIMARY KEY (class_id, user_id);


--
-- Name: t_zys6z6hrol7 t_zys6z6hrol7_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.t_zys6z6hrol7
    ADD CONSTRAINT t_zys6z6hrol7_pkey PRIMARY KEY (user_id, affiliation_id);


--
-- Name: themeConfig themeConfig_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."themeConfig"
    ADD CONSTRAINT "themeConfig_pkey" PRIMARY KEY (id);


--
-- Name: tokenBlacklist tokenBlacklist_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."tokenBlacklist"
    ADD CONSTRAINT "tokenBlacklist_pkey" PRIMARY KEY (id);


--
-- Name: tokenControlConfig tokenControlConfig_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."tokenControlConfig"
    ADD CONSTRAINT "tokenControlConfig_pkey" PRIMARY KEY (key);


--
-- Name: uiButtonSchemasRoles uiButtonSchemasRoles_uid_roleName_key; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."uiButtonSchemasRoles"
    ADD CONSTRAINT "uiButtonSchemasRoles_uid_roleName_key" UNIQUE (uid, "roleName");


--
-- Name: uiSchemaServerHooks uiSchemaServerHooks_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."uiSchemaServerHooks"
    ADD CONSTRAINT "uiSchemaServerHooks_pkey" PRIMARY KEY (id);


--
-- Name: uiSchemaTemplates uiSchemaTemplates_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."uiSchemaTemplates"
    ADD CONSTRAINT "uiSchemaTemplates_pkey" PRIMARY KEY (key);


--
-- Name: uiSchemaTreePath uiSchemaTreePath_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."uiSchemaTreePath"
    ADD CONSTRAINT "uiSchemaTreePath_pkey" PRIMARY KEY (ancestor, descendant);


--
-- Name: uiSchemas uiSchemas_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."uiSchemas"
    ADD CONSTRAINT "uiSchemas_pkey" PRIMARY KEY ("x-uid");


--
-- Name: userDataSyncRecordsResources userDataSyncRecordsResources_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."userDataSyncRecordsResources"
    ADD CONSTRAINT "userDataSyncRecordsResources_pkey" PRIMARY KEY (id);


--
-- Name: userDataSyncRecords userDataSyncRecords_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."userDataSyncRecords"
    ADD CONSTRAINT "userDataSyncRecords_pkey" PRIMARY KEY (id);


--
-- Name: userDataSyncSources userDataSyncSources_name_key; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."userDataSyncSources"
    ADD CONSTRAINT "userDataSyncSources_name_key" UNIQUE (name);


--
-- Name: userDataSyncSources userDataSyncSources_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."userDataSyncSources"
    ADD CONSTRAINT "userDataSyncSources_pkey" PRIMARY KEY (id);


--
-- Name: userDataSyncTasks userDataSyncTasks_batch_key; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."userDataSyncTasks"
    ADD CONSTRAINT "userDataSyncTasks_batch_key" UNIQUE (batch);


--
-- Name: userDataSyncTasks userDataSyncTasks_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."userDataSyncTasks"
    ADD CONSTRAINT "userDataSyncTasks_pkey" PRIMARY KEY (id);


--
-- Name: userWorkflowTasks userWorkflowTasks_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."userWorkflowTasks"
    ADD CONSTRAINT "userWorkflowTasks_pkey" PRIMARY KEY (id);


--
-- Name: usersAuthenticators usersAuthenticators_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."usersAuthenticators"
    ADD CONSTRAINT "usersAuthenticators_pkey" PRIMARY KEY (authenticator, "userId");


--
-- Name: usersVerificators usersVerificators_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."usersVerificators"
    ADD CONSTRAINT "usersVerificators_pkey" PRIMARY KEY (verificator, "userId");


--
-- Name: usersVerifiers usersVerifiers_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."usersVerifiers"
    ADD CONSTRAINT "usersVerifiers_pkey" PRIMARY KEY (verifier, "userId");


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_resetToken_key; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "users_resetToken_key" UNIQUE ("resetToken");


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: verifications verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.verifications
    ADD CONSTRAINT verifications_pkey PRIMARY KEY (id);


--
-- Name: verifications_providers verifications_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.verifications_providers
    ADD CONSTRAINT verifications_providers_pkey PRIMARY KEY (id);


--
-- Name: verificators verificators_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.verificators
    ADD CONSTRAINT verificators_pkey PRIMARY KEY (name);


--
-- Name: verifiers verifiers_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.verifiers
    ADD CONSTRAINT verifiers_pkey PRIMARY KEY (name);


--
-- Name: workflowCategories workflowCategories_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."workflowCategories"
    ADD CONSTRAINT "workflowCategories_pkey" PRIMARY KEY (id);


--
-- Name: workflowCategoryRelations workflowCategoryRelations_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."workflowCategoryRelations"
    ADD CONSTRAINT "workflowCategoryRelations_pkey" PRIMARY KEY ("workflowId", "categoryId");


--
-- Name: workflowStats workflowStats_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."workflowStats"
    ADD CONSTRAINT "workflowStats_pkey" PRIMARY KEY (key);


--
-- Name: workflowTasks workflowTasks_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."workflowTasks"
    ADD CONSTRAINT "workflowTasks_pkey" PRIMARY KEY (id);


--
-- Name: workflowVersionStats workflowVersionStats_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public."workflowVersionStats"
    ADD CONSTRAINT "workflowVersionStats_pkey" PRIMARY KEY (id);


--
-- Name: workflows workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: nocobase
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_pkey PRIMARY KEY (id);


--
-- Name: affiliation_parent_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX affiliation_parent_id ON public.affiliation USING btree ("parentId");


--
-- Name: api_keys_role_name; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX api_keys_role_name ON public."apiKeys" USING btree ("roleName");


--
-- Name: attachments_created_by_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX attachments_created_by_id ON public.attachments USING btree ("createdById");


--
-- Name: attachments_storage_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX attachments_storage_id ON public.attachments USING btree ("storageId");


--
-- Name: attachments_updated_by_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX attachments_updated_by_id ON public.attachments USING btree ("updatedById");


--
-- Name: authenticators_created_by_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX authenticators_created_by_id ON public.authenticators USING btree ("createdById");


--
-- Name: block_template_links_block_uid; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX block_template_links_block_uid ON public."blockTemplateLinks" USING btree ("blockUid");


--
-- Name: block_template_links_template_block_uid; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX block_template_links_template_block_uid ON public."blockTemplateLinks" USING btree ("templateBlockUid");


--
-- Name: block_template_links_template_key; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX block_template_links_template_key ON public."blockTemplateLinks" USING btree ("templateKey");


--
-- Name: block_templates_uid; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX block_templates_uid ON public."blockTemplates" USING btree (uid);


--
-- Name: class_affiliation_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX class_affiliation_id ON public.class USING btree (affiliation_id);


--
-- Name: collection_category_category_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX collection_category_category_id ON public."collectionCategory" USING btree ("categoryId");


--
-- Name: custom_requests_roles_role_name; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX custom_requests_roles_role_name ON public."customRequestsRoles" USING btree ("roleName");


--
-- Name: data_sources_collections_data_source_key; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX data_sources_collections_data_source_key ON public."dataSourcesCollections" USING btree ("dataSourceKey");


--
-- Name: data_sources_collections_name_data_source_key; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE UNIQUE INDEX data_sources_collections_name_data_source_key ON public."dataSourcesCollections" USING btree (name, "dataSourceKey");


--
-- Name: data_sources_fields_collection_key; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX data_sources_fields_collection_key ON public."dataSourcesFields" USING btree ("collectionKey");


--
-- Name: data_sources_fields_data_source_key; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX data_sources_fields_data_source_key ON public."dataSourcesFields" USING btree ("dataSourceKey");


--
-- Name: data_sources_fields_name_collection_name_data_source_key; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE UNIQUE INDEX data_sources_fields_name_collection_name_data_source_key ON public."dataSourcesFields" USING btree (name, "collectionName", "dataSourceKey");


--
-- Name: data_sources_roles_data_source_key; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX data_sources_roles_data_source_key ON public."dataSourcesRoles" USING btree ("dataSourceKey");


--
-- Name: data_sources_roles_resources_actions_roles_resource_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX data_sources_roles_resources_actions_roles_resource_id ON public."dataSourcesRolesResourcesActions" USING btree ("rolesResourceId");


--
-- Name: data_sources_roles_resources_actions_scope_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX data_sources_roles_resources_actions_scope_id ON public."dataSourcesRolesResourcesActions" USING btree ("scopeId");


--
-- Name: data_sources_roles_resources_data_source_key; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX data_sources_roles_resources_data_source_key ON public."dataSourcesRolesResources" USING btree ("dataSourceKey");


--
-- Name: data_sources_roles_resources_role_name; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX data_sources_roles_resources_role_name ON public."dataSourcesRolesResources" USING btree ("roleName");


--
-- Name: data_sources_roles_resources_scopes_data_source_key; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX data_sources_roles_resources_scopes_data_source_key ON public."dataSourcesRolesResourcesScopes" USING btree ("dataSourceKey");


--
-- Name: data_sources_roles_role_name; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX data_sources_roles_role_name ON public."dataSourcesRoles" USING btree ("roleName");


--
-- Name: desktop_routes_parent_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX desktop_routes_parent_id ON public."desktopRoutes" USING btree ("parentId");


--
-- Name: executions_workflow_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX executions_workflow_id ON public.executions USING btree ("workflowId");


--
-- Name: fields_collection_name_name; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE UNIQUE INDEX fields_collection_name_name ON public.fields USING btree ("collectionName", name);


--
-- Name: fields_parent_key; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX fields_parent_key ON public.fields USING btree ("parentKey");


--
-- Name: fields_reverse_key; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX fields_reverse_key ON public.fields USING btree ("reverseKey");


--
-- Name: flow_nodes_downstream_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX flow_nodes_downstream_id ON public.flow_nodes USING btree ("downstreamId");


--
-- Name: flow_nodes_upstream_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX flow_nodes_upstream_id ON public.flow_nodes USING btree ("upstreamId");


--
-- Name: flow_nodes_workflow_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX flow_nodes_workflow_id ON public.flow_nodes USING btree ("workflowId");


--
-- Name: iframe_html_created_by_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX iframe_html_created_by_id ON public."iframeHtml" USING btree ("createdById");


--
-- Name: issued_tokens_jti; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX issued_tokens_jti ON public."issuedTokens" USING btree (jti);


--
-- Name: jobs_execution_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX jobs_execution_id ON public.jobs USING btree ("executionId");


--
-- Name: jobs_node_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX jobs_node_id ON public.jobs USING btree ("nodeId");


--
-- Name: jobs_upstream_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX jobs_upstream_id ON public.jobs USING btree ("upstreamId");


--
-- Name: main_affiliation_path_path; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX main_affiliation_path_path ON public.main_affiliation_path USING btree (path);


--
-- Name: main_desktop_routes_path_path; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX main_desktop_routes_path_path ON public."main_desktopRoutes_path" USING btree (path);


--
-- Name: main_mobile_routes_path_path; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX main_mobile_routes_path_path ON public."main_mobileRoutes_path" USING btree (path);


--
-- Name: mobile_routes_parent_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX mobile_routes_parent_id ON public."mobileRoutes" USING btree ("parentId");


--
-- Name: notification_channels_created_by_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX notification_channels_created_by_id ON public."notificationChannels" USING btree ("createdById");


--
-- Name: notification_in_app_messages_channel_name; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX notification_in_app_messages_channel_name ON public."notificationInAppMessages" USING btree ("channelName");


--
-- Name: otp_records_verifier_name; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX otp_records_verifier_name ON public."otpRecords" USING btree ("verifierName");


--
-- Name: roles_desktop_routes_role_name; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX roles_desktop_routes_role_name ON public."rolesDesktopRoutes" USING btree ("roleName");


--
-- Name: roles_mobile_routes_role_name; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX roles_mobile_routes_role_name ON public."rolesMobileRoutes" USING btree ("roleName");


--
-- Name: roles_resources_actions_roles_resource_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX roles_resources_actions_roles_resource_id ON public."rolesResourcesActions" USING btree ("rolesResourceId");


--
-- Name: roles_resources_actions_scope_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX roles_resources_actions_scope_id ON public."rolesResourcesActions" USING btree ("scopeId");


--
-- Name: roles_resources_role_name_name; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE UNIQUE INDEX roles_resources_role_name_name ON public."rolesResources" USING btree ("roleName", name);


--
-- Name: roles_uischemas_ui_schema_x_uid; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX roles_uischemas_ui_schema_x_uid ON public."rolesUischemas" USING btree ("uiSchemaXUid");


--
-- Name: roles_users_user_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX roles_users_user_id ON public."rolesUsers" USING btree ("userId");


--
-- Name: schedule_class_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX schedule_class_id ON public.schedule USING btree (class_id);


--
-- Name: schedule_subject_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX schedule_subject_id ON public.schedule USING btree (subject_id);


--
-- Name: schedule_user_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX schedule_user_id ON public.schedule USING btree (user_id);


--
-- Name: score_student_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX score_student_id ON public.score USING btree (student_id);


--
-- Name: score_subject_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX score_subject_id ON public.score USING btree (subject_id);


--
-- Name: student_class_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX student_class_id ON public.student USING btree (class_id);


--
-- Name: student_user_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX student_user_id ON public.student USING btree (user_id);


--
-- Name: subject_affiliation_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX subject_affiliation_id ON public.subject USING btree (affiliation_id);


--
-- Name: system_settings_logo_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX system_settings_logo_id ON public."systemSettings" USING btree ("logoId");


--
-- Name: t_js3c1e4rwku_user_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX t_js3c1e4rwku_user_id ON public.t_js3c1e4rwku USING btree (user_id);


--
-- Name: t_zys6z6hrol7_affiliation_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX t_zys6z6hrol7_affiliation_id ON public.t_zys6z6hrol7 USING btree (affiliation_id);


--
-- Name: t_zys6z6hrol7_user_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX t_zys6z6hrol7_user_id ON public.t_zys6z6hrol7 USING btree (user_id);


--
-- Name: token_blacklist_token; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX token_blacklist_token ON public."tokenBlacklist" USING btree (token);


--
-- Name: token_control_config_created_by_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX token_control_config_created_by_id ON public."tokenControlConfig" USING btree ("createdById");


--
-- Name: ui_button_schemas_roles_role_name; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX ui_button_schemas_roles_role_name ON public."uiButtonSchemasRoles" USING btree ("roleName");


--
-- Name: ui_button_schemas_roles_uid; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX ui_button_schemas_roles_uid ON public."uiButtonSchemasRoles" USING btree (uid);


--
-- Name: ui_schema_server_hooks_uid; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX ui_schema_server_hooks_uid ON public."uiSchemaServerHooks" USING btree (uid);


--
-- Name: ui_schema_templates_uid; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX ui_schema_templates_uid ON public."uiSchemaTemplates" USING btree (uid);


--
-- Name: ui_schema_tree_path_descendant; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX ui_schema_tree_path_descendant ON public."uiSchemaTreePath" USING btree (descendant);


--
-- Name: user_data_sync_records_resources_record_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX user_data_sync_records_resources_record_id ON public."userDataSyncRecordsResources" USING btree ("recordId");


--
-- Name: user_data_sync_sources_created_by_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX user_data_sync_sources_created_by_id ON public."userDataSyncSources" USING btree ("createdById");


--
-- Name: user_data_sync_tasks_created_by_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX user_data_sync_tasks_created_by_id ON public."userDataSyncTasks" USING btree ("createdById");


--
-- Name: user_data_sync_tasks_source_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX user_data_sync_tasks_source_id ON public."userDataSyncTasks" USING btree ("sourceId");


--
-- Name: user_workflow_tasks_user_id_type; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE UNIQUE INDEX user_workflow_tasks_user_id_type ON public."userWorkflowTasks" USING btree ("userId", type);


--
-- Name: users_authenticators_created_by_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX users_authenticators_created_by_id ON public."usersAuthenticators" USING btree ("createdById");


--
-- Name: users_authenticators_updated_by_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX users_authenticators_updated_by_id ON public."usersAuthenticators" USING btree ("updatedById");


--
-- Name: users_authenticators_user_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX users_authenticators_user_id ON public."usersAuthenticators" USING btree ("userId");


--
-- Name: users_created_by_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX users_created_by_id ON public.users USING btree ("createdById");


--
-- Name: users_verificators_created_by_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX users_verificators_created_by_id ON public."usersVerificators" USING btree ("createdById");


--
-- Name: users_verificators_updated_by_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX users_verificators_updated_by_id ON public."usersVerificators" USING btree ("updatedById");


--
-- Name: users_verificators_user_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX users_verificators_user_id ON public."usersVerificators" USING btree ("userId");


--
-- Name: users_verifiers_created_by_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX users_verifiers_created_by_id ON public."usersVerifiers" USING btree ("createdById");


--
-- Name: users_verifiers_updated_by_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX users_verifiers_updated_by_id ON public."usersVerifiers" USING btree ("updatedById");


--
-- Name: users_verifiers_user_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX users_verifiers_user_id ON public."usersVerifiers" USING btree ("userId");


--
-- Name: verifications_provider_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX verifications_provider_id ON public.verifications USING btree ("providerId");


--
-- Name: workflow_category_relations_category_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX workflow_category_relations_category_id ON public."workflowCategoryRelations" USING btree ("categoryId");


--
-- Name: workflow_category_relations_workflow_category_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX workflow_category_relations_workflow_category_id ON public."workflowCategoryRelations" USING btree ("workflowCategoryId");


--
-- Name: workflow_tasks_type_key; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE UNIQUE INDEX workflow_tasks_type_key ON public."workflowTasks" USING btree (type, key);


--
-- Name: workflow_tasks_user_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX workflow_tasks_user_id ON public."workflowTasks" USING btree ("userId");


--
-- Name: workflow_tasks_workflow_id; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE INDEX workflow_tasks_workflow_id ON public."workflowTasks" USING btree ("workflowId");


--
-- Name: workflows_key_current; Type: INDEX; Schema: public; Owner: nocobase
--

CREATE UNIQUE INDEX workflows_key_current ON public.workflows USING btree (key, current);


--
-- PostgreSQL database dump complete
--

